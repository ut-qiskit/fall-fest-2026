# UW-Madison WQCC’s Official Sponsored Prompt

## Reusable quantum execution planner

Back in 2016, cloud access allowed students and researchers alike to run experiments on a five qubit quantum processor. Now presently ten years later, quantum processors and Qiskit have advanced dramatically, however most useful workflows still face a full stack problem: a circuit may have more qubits than an available device, require excessive routing, become too deep under hardware constraints, or lose accuracy to nonuniform noise.

Hence, In this challenge, teams will build a reusable quantum execution planner. For each previously unseen benchmark instance, the planner will receive a Qiskit circuit, one or more target observables, a backend topology and noise profile, a maximum subcircuit width, and a fixed sampling budget.

It must first decide whether the circuit should be executed directly or decomposed using circuit cutting. If cutting is selected, it must choose gate and/or wire cuts, partition the circuit, map the subcircuits to hardware, allocate shots among the resulting subexperiments, and return a plan that allows the requested observables to be reconstructed with some quantified uncertainty. Teams will not optimize a single arbitrary handpicked circuit as that lacks practicability to use such a planner generally, instead they will develop against public, procedurally generated families of structured workloads, including QAOA/MaxCut, spin dynamics, variational energy estimation, and controlled modular circuits, and will be evaluated on hidden seeds, held out sizes, new backend conditions, and examples for which the correct decision is not to cut. The current baseline for this challenge will include direct hardware aware transpilation and Qiskit’s automatic cut finder.

There are three proposed tracks of varying depth to accommodate all participants' technical levels which may help with your approach tackling this challenge: Explorer, Builder, & Frontier. Explorer: Apply Qiskit’s circuit cutting addon, reconstruct observables, and explain the width depth sampling trade off, with any extra relevant analysis. Builder: Improve at least one stage, such as cut placement, mapping, circuit preprocessing, shot allocation, or uncertainty estimation. Frontier: Submit an integrated planner evaluated on unseen circuits and backend conditions. Some optional methods/ideas to explore may include graph or hypergraph partitioning, tensor network or entanglement proxies, Bayesian optimization, evolutionary search, reinforcement learning, or supervised cut  vs run prediction.

Deliverables may include a reproducible notebook or repository, the planner, quantitative comparisons with the baselines, an execution plan visualization, and a concise discussion of successes, failures, and generalization. The primary score will measure observable accuracy under a fixed resource budget, with additional credit for efficiency, scalability, reproducibility, and technical insight.

This challenge celebrates the first decade of quantum on the cloud by asking participants to help design the software intelligence needed for the next one, which will not merely consist of larger processors, but (hopefully) smarter ways to use limited quantum resources.

---

## Start here

Work through the three notebooks in order. They explain the examples, provide
code you can run, and leave exercises and written response spaces for your own
work. Basic Python and introductory quantum circuits are assumed. A presenter
or instructor is not required. Allow **4½–6½ hours** for the guided exercises;
developing and evaluating your own hackathon contribution takes additional time.

| File | What you will learn |
|---|---|
| [01_cut_and_reconstruct.ipynb](01_cut_and_reconstruct.ipynb) | Follow one real gate cut through local experiments, signed reconstruction, shot accounting, and uncertainty. Allow 90–120 minutes. |
| [02_workloads_and_shared_budget.ipynb](02_workloads_and_shared_budget.ipynb) | Understand the four circuit families and estimate several observables within one sampling allowance. Allow 90–120 minutes. |
| [03_improve_and_evaluate.ipynb](03_improve_and_evaluate.ipynb) | Inspect candidate plans, change a selection rule, compare baselines, and design a generalization test. Allow 90–150 minutes. |
| [python/README.md](python/README.md) | Install the environment, find each script, understand the evaluation contract, and distinguish participant work from leader responsibilities. |

The notebooks include saved examples, diagrams, plots, hints, and optional
reference answers in the `python` folder. Their exercises remain unanswered.
They generate their own input circuits, so there is no dataset to download.
Keep the complete extracted folder together. Start with the setup instructions
inside Workbook 1 or the Python guide. The experiments run locally with Aer;
no IBM account, access token, or quantum hardware is required.

## What you are building

A **quantum execution planner** takes a circuit and a measurement request and
decides how to run it within the available resources. A request includes:

- A Qiskit circuit whose gate parameters already have numerical values.
- One or more observables, each specifying an expectation value to estimate.
- A hardware topology and noise profile.
- A maximum physical experiment width and one total shot allowance.

The planner can compile and execute the circuit directly when it fits. It can
also cut interactions, prepare smaller experiments, allocate shots, and
reconstruct the requested expectations with quantified uncertainty. Every shot
across all targets, Pauli terms, cut recipes, and fragments counts toward the
same allowance. Twelve experiments with 1,000 shots each cost 12,000 shots.

Your scientific question is whether a planning choice helps under those
constraints, and where it fails. Gate angles and target observables belong to
the request: the task is to estimate them faithfully. For example, this package
does not ask you to train a QAOA optimizer or find the best variational angles.

The supplied baselines are hardware-aware direct execution and Qiskit's
automatic gate-cut finder. The starter adds a simple structured-cut candidate
and an editable selection rule. The smallest persistent edit point is
[`python/wqcc_planner/participant.py`](python/wqcc_planner/participant.py).
Workbook 3 teaches that interface before asking you to extend it.

## Choose a track

The following descriptions reproduce the track wording in the official prompt:

> Explorer: Apply Qiskit’s circuit cutting addon, reconstruct observables, and explain the width depth sampling trade off, with any extra relevant analysis.

> Builder: Improve at least one stage, such as cut placement, mapping, circuit preprocessing, shot allocation, or uncertainty estimation.

> Frontier: Submit an integrated planner evaluated on unseen circuits and backend conditions.

All three workbooks are available to every track. Completing a numbered notebook
does not automatically complete the corresponding track.

**Explorer:** begin with Workbook 1, then use Workbook 2 to choose a few
variations you can explain. Keep your reconstruction, a shot ledger, uncertainty,
and a discussion of how width, depth, and sampling changed.

**Builder:** use Workbook 3 to develop one specific change. Compare it with
the unchanged method on common cases and budgets. Keep unsuccessful cases in
the results. The supplied policy is a hypothesis to investigate; its example
contains genuine feasibility failures and is not presented as an improvement.

**Frontier:** integrate the stages into a reusable planner and test across the
four families, including new seeds, sizes, backend conditions, and no-cut
controls. The final notebook supplies a starting workflow and capstone design
exercise. A third completed workbook alone does not establish generalization.

These are practical starting routes. Final submission procedures and assessment
scope will come from the event organizers.

## The four workload families

| Family | Circuit and question | What the planner preserves |
|---|---|---|
| QAOA / MaxCut | Alternating graph-interaction and mixing layers. Estimate a weighted ZZ correlation related to expected cut weight. | The supplied graph, angles, and observable. A lower execution error is different from finding a better graph cut. |
| Spin dynamics | A product-formula circuit for an Ising model with fields. Estimate transverse magnetization. | The actual discretized circuit. The score does not include its approximation error against continuous Hamiltonian evolution. |
| Variational energy estimation | A fixed trial circuit and a normalized Ising Hamiltonian. Estimate its energy. | The supplied trial parameters and energy observable. This is one estimation step, not a full variational optimization. |
| Controlled modular circuits | Small circuit modules connected by controlled rotations. Estimate an endpoint correlation. | The modules and interactions. “Modular” refers to circuit modules, not modular arithmetic or Shor's algorithm. |

A procedural generator builds another reproducible instance from settings and
a random seed. It varies circuit structure, weights, angles, labels, and
conditions within these definitions. The [generator reference](python/README.md#generator-details)
gives exact conventions and parameters. Simple product-state controls check
cases where direct execution already has an exact noiseless answer.

An additional family can be a useful research extension. Label it separately
and retain the common required comparisons for your track; a handpicked new
family alone does not establish the prompt's generalization claim.

## Judging

The prompt makes **observable accuracy under a fixed resource budget** primary,
with additional credit for efficiency, scalability, reproducibility, and
technical insight. The following weights are proposed:

| Criterion | Proposed weight | Useful evidence |
|---|---:|---|
| Observable accuracy | 60% | Error against ideal references on matching cases, with failures and coverage retained. |
| Efficiency | 10% | Physical shots, experiment counts, compiled width/depth, gate counts, and classical processing cost. |
| Scalability | 10% | Behavior as the relevant size, structure, or backend conditions change, including limits. |
| Reproducibility | 10% | Runnable source, environment, configurations, seeds, and complete records. |
| Technical insight | 10% | Correct reasoning, a controlled comparison, uncertainty, and an explanation of successes and failures. |

**The weights remain proposed.** The scripts compute a development metric,
macro root-mean-square error (RMSE), alongside feasibility coverage. They do
not calculate a final 100-point competition grade. The conversion from RMSE to
points, final per-track suites, repetition counts, tie handling, submission
procedure, and recognition categories still require organizer confirmation.

The [evaluation contract](python/README.md#evaluation-contract) defines the
implemented aggregation order and resource checks. A failed required case is
retained and prevents a qualifying full-suite aggregate. Direct execution above
the width limit is unavailable; compare its accuracy on cases where it can run.
Optional stress cases must be identified separately. State which cases and
repetitions support a claim.

## What to keep for your submission

Prepare your runnable notebook or repository, the planner or studied method,
and instructions to reproduce the results. Include your configurations and
seeds, comparisons with baselines, the complete results including failures,
an actual execution-plan visualization, and a concise account of what you
learned. Explain reconstruction, uncertainty, and resource accounting. State
which examples you used to develop the method and which were unseen when you
froze it. Follow the organizers' final upload instructions when announced.

## Technical scope

The supplied implementation supports **gate cutting**, small bound unitary
circuits, one to eight normalized Hermitian Pauli-sum targets, and synthetic
local noise. Its generators support two through ten qubits. Small QPD
expansions are enumerated exactly; finite-shot measurements still have sampling
uncertainty. Wire cutting is an optional extension permitted by the prompt and
is not implemented by the starter.

All teaching examples are classically tractable. They support correctness
checks and comparisons of execution plans under a chosen width limit. They
provide no evidence of quantum advantage or speedup over classical methods.
Workbook 1 includes both a statevector check and a closed-form check for its
four-qubit circuit. Non-Clifford gates alone do not make a circuit hard to
simulate.

The noise profiles are synthetic depolarizing/readout models with
location-dependent rates, not live device calibrations. The sampling intervals
describe the reconstructed noisy quantity under the stated fixed-allocation
model. They do not bound unknown noise bias against the ideal answer.
Changing allocation adaptively or sharing measurements requires corresponding
uncertainty and covariance analysis.

Ideal references are computed separately for diagnostics. Keep them out of
planner decisions and reported estimates. The local runner executes trusted
Python; it is not a secure judging service. Leaders must keep hidden cases and
reference answers separate and control final execution. Both roles can use
the public scripts; the [Python guide](python/README.md#for-event-leaders)
explains the distinction.

## Resources

Begin with the first three links. Use the remaining guides and papers when
they become relevant to your investigation. The linked papers are optional
reading, not prerequisites or additional challenge requirements.

| Resource | Why read it? |
|---|---|
| [Qiskit cutting explanation](https://qiskit.github.io/qiskit-addon-cutting/explanation/) | Gate versus wire cuts, local operations, and sampling overhead. For the RZZ recipe, preserve the implementation’s coefficient/experiment pairing. |
| [Gate cutting to reduce circuit width](https://qiskit.github.io/qiskit-addon-cutting/tutorials/01_gate_cutting_to_reduce_circuit_width.html) | Trace partitioning, experiment generation, and reconstruction. |
| [Exact sampling coefficients](https://qiskit.github.io/qiskit-addon-cutting/how-tos/how_to_generate_exact_sampling_coefficients.html) | Understand why exact enumeration of weights still requires shot sampling. |
| [Automatic cut finding](https://qiskit.github.io/qiskit-addon-cutting/tutorials/04_automatic_cut_finding.html) | Understand the baseline search, device constraints, and search-status metadata. |
| [Multiple observables](https://qiskit.github.io/qiskit-addon-cutting/how-tos/how_to_provide_multiple_observables.html) | Follow weighted Pauli reconstruction. Our package additionally enforces a shared shot allowance. |
| [Wire cuts with CutWire](https://qiskit.github.io/qiskit-addon-cutting/how-tos/how_to_specify_cut_wires.html) | Explore an extension beyond the supplied gate-cutting implementation. |
| [Qiskit bit ordering](https://quantum.cloud.ibm.com/docs/en/guides/bit-ordering) | Resolve the difference between diagram wire order and Pauli/bitstring order. |
| [Aer noise models](https://qiskit.github.io/qiskit-aer/tutorials/3_building_noise_models.html) | Understand the distinction between gate and readout errors and their physical locations. |
| [Peng et al., Simulating Large Quantum Circuits on a Small Quantum Computer](https://arxiv.org/abs/1904.00102v2) | Foundational relations between partition structure and simulation cost. |
| [Mitarai and Fujii, Constructing a virtual two-qubit gate by sampling single-qubit operations](https://arxiv.org/abs/1909.07534v2) | The gate-cutting decomposition and sampling argument behind local recipes. |
| [Schmitt et al., Cutting circuits with multiple two-qubit unitaries](https://arxiv.org/abs/2312.11638v4) | Joint decompositions can change overhead relative to independent cuts. |
| [Brenner et al., Optimal wire cutting with classical communication](https://arxiv.org/abs/2302.03366v1) | See how permitted communication changes achievable wire-cutting costs. |
| [Harada et al., Doubly optimal parallel wire cutting without ancilla qubits](https://arxiv.org/abs/2303.07340v2) | An advanced construction using local operations and classical communication. |
| [Chen et al., Enhanced Quantum Circuit Cutting Framework for Sampling Overhead Reduction / ShotQC](https://arxiv.org/abs/2412.17704v3) | Investigate allocation and cut parameterization; check the objective and inference assumptions before adapting them. |
| [Farhi et al., A Quantum Approximate Optimization Algorithm](https://arxiv.org/abs/1411.4028) | Background on QAOA cost and mixing layers. Our generator supplies fixed angles. |
| [Peruzzo et al., A variational eigenvalue solver on a quantum processor](https://arxiv.org/abs/1304.3061) | Background on separating state preparation, energy estimation, and parameter optimization. |

The package uses cutting add-on 0.10.0. Workbook 1 obtains its coefficients
from the add-on and checks reconstruction independently. Preserve each returned
coefficient/experiment pairing and use Qiskit's RZZ sign convention. See the
[decomposition implementation](https://qiskit.github.io/qiskit-addon-cutting/_modules/qiskit_addon_cutting/qpd/decompositions.html)
and [Qiskit's RZZ definition](https://quantum.cloud.ibm.com/docs/en/api/qiskit/qiskit.circuit.library.RZZGate).
Online tutorials can use different environments or hardware execution; the
included notebook examples are local.
