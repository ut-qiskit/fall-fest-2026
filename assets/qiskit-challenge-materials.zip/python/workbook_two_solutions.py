"""Optional worked answers for Workbook 2. Read after attempting each exercise.

The utility functions also support the workbook's completed examples.
Importing this module does not run experiments or change participant code.
"""
import numpy as np
from qiskit.quantum_info import SparsePauliOp
from wqcc_planner.instances import pauli_label


def weighted_cut_fraction(bits, edges, weights):
    """Classical cut weight / total weight; bits are indexed q0, q1, ... ."""
    total = sum(weights)
    if total <= 0:
        raise ValueError("positive total weight required")
    return sum(w for (a, b), w in zip(edges, weights) if bits[a] != bits[b]) / total


def normalized_mean_z(n):
    return SparsePauliOp.from_list([(pauli_label(n, {q: "Z"}), 1/n) for q in range(n)])


def exercise_1():
    # Since f(E)=(1-E)/2 decreases, f(upper) is the new lower endpoint.
    return .35, (.25, .45)


def exercise_2():
    return ["sampling", "hardware", "product_formula"]


def exercise_3(n):
    return normalized_mean_z(n)


def exercise_4():
    return dict(family="qaoa", generator_version=2, n_qubits=4, seed=314159,
                graph="tree", relabel=True, layers=1, max_width=4,
                shots=12000, noise="ideal")


EXERCISE_5 = """A circuit seed changes the specimen: graph choices, angles,
weights or fields, and/or labels, according to family and settings. A measurement
seed gives new finite-shot outcomes for a fixed experiment. A transpiler seed
may change a randomized compilation choice without changing the ideal circuit.
Fresh circuit specimens test more than repeated measurements. Compare allocators
on the same circuit, targets, hardware, constraints, transpilation settings, and
total budget; use multiple measurement seeds without pooling them into one
budget-limited request. A new seed does not guarantee a different small graph.
"""


def exercise_6(n=4):
    return SparsePauliOp.from_list([("I"*n, .5)])


EXERCISE_7 = """One useful follow-up multiplies only the synthetic error rates
by a declared factor while preserving the bound circuit, targets, topology,
width, budget, allocator, and compilation seed. Predict how noise bias and
sampling variance might compete, then collect multiple independent repeats.
Report every outcome. A noise sweep uses a synthetic model, not an IBM device
calibration. Changing only the shot budget instead studies a resource trade-off;
changing only the generator seed tests behavior on a new instance.
"""
