"""Replace this module for a Builder submission.

The default makes no claim of outperforming direct or automatic cutting.
Candidate selection receives no reference expectation and spends no pilot shots.
"""
import time
from .instances import Instance
from .engine import ExecutionPlan, InfeasiblePlan, Limits, plan


def candidate_features(candidate: ExecutionPlan) -> dict:
    summary = candidate.summary()
    return {key: summary[key] for key in (
        "maximum_qpd_overhead", "maximum_two_qubit_depth", "experiments",
        "maximum_experiment_width", "shot_weighted_two_qubit_gates")}


def select_candidate(instance: Instance, candidates: list[ExecutionPlan]) -> ExecutionPlan:
    """EDIT HERE: rank candidates using circuit/hardware/resource information.

    Starter rule: choose feasible direct first, otherwise smallest QPD overhead.
    A more ambitious policy could model noise and sampling error jointly. Raw
    gamma squared is not a measured MSE, and feature changes are not guarantees.
    """
    if not candidates:
        raise InfeasiblePlan("no candidate passed the resource constraints")
    return min(candidates, key=lambda c: (
        c.strategy != "direct", c.summary()["maximum_qpd_overhead"],
        c.summary()["maximum_two_qubit_depth"]))


def build_plan(instance: Instance, allocation: str = "coefficient", *, limits: Limits | None = None) -> ExecutionPlan:
    began = time.perf_counter()
    candidates, rejected = [], []
    for strategy in ("direct", "auto_cut", "structured_cut"):
        try:
            candidates.append(plan(instance, strategy, allocation, limits=limits))
        except InfeasiblePlan as error:
            rejected.append({"strategy": strategy, "reason": str(error)})
    chosen = select_candidate(instance, candidates)
    chosen.metadata["candidate_features"] = [dict(strategy=c.strategy, **candidate_features(c)) for c in candidates]
    chosen.metadata["rejected_candidates"] = rejected
    chosen.metadata["participant_hook"] = "wqcc_planner.participant.select_candidate"
    chosen.metadata["chosen_candidate_planning_seconds"] = chosen.metadata["planning_seconds"]
    chosen.metadata["planning_seconds"] = time.perf_counter() - began
    return chosen
