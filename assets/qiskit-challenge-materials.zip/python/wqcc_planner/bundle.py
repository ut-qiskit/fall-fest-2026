"""Several named observables with one physical-shot budget.

Every target has independent experiment records; this implementation does not
reuse measurements across targets. Planning is data-free. Candidate allocations
are replaced by a single global fixed allocation before any backend runs.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
import math
import numbers
import time
from typing import Any, Mapping

import numpy as np
from qiskit.quantum_info import SparsePauliOp

from . import engine, participant
from .engine import ExecutionPlan, InfeasiblePlan, Limits
from .instances import Instance
from .statistics import allocate_shots


MAX_TARGETS = 8


def _validated_observable(observable: SparsePauliOp, width: int) -> SparsePauliOp:
    if not isinstance(observable, SparsePauliOp):
        raise TypeError("each target must be a SparsePauliOp")
    if observable.num_qubits != width:
        raise ValueError("target and circuit widths must agree")
    coefficients = np.asarray(observable.coeffs, dtype=complex)
    if not np.all(np.isfinite(coefficients)):
        raise ValueError("target coefficients must be finite")
    if np.any(coefficients.imag != 0):
        raise ValueError("target Pauli coefficients must be real")
    # Combine duplicate Paulis before testing the bound. No automatic rescaling:
    # changing a target's normalization changes the scientific question.
    simplified = observable.simplify(atol=0, rtol=0)
    if not np.all(np.isfinite(simplified.coeffs)):
        raise ValueError("combined target coefficients must be finite")
    if math.fsum(abs(float(c.real)) for c in simplified.coeffs) > 1.0 + 1e-10:
        raise ValueError("normalize each target's sum of absolute Pauli coefficients to <= 1")
    return SparsePauliOp.from_list([(p, float(c.real)) for p, c in simplified.to_list()])


def _observable_spec(observable: SparsePauliOp) -> list[list[Any]]:
    return [[label, float(coefficient.real)] for label, coefficient in observable.to_list()]


@dataclass
class MultiObservableInstance:
    """A circuit/backend/budget from ``base`` and one to eight named targets.

    ``base.observable`` is not an extra target. Pass it explicitly when wanted.
    Target insertion order defines deterministic allocation tie breaks and seeds.
    Coefficients are checked, duplicate terms combined, and never rescaled.
    """

    base: Instance
    targets: Mapping[str, SparsePauliOp]

    def __post_init__(self) -> None:
        if not isinstance(self.base, Instance):
            raise TypeError("base must be an Instance")
        if not isinstance(self.targets, Mapping) or not 1 <= len(self.targets) <= MAX_TARGETS:
            raise ValueError(f"provide 1..{MAX_TARGETS} named targets")
        if isinstance(self.base.shots, bool) or not isinstance(self.base.shots, numbers.Integral) or self.base.shots < 2:
            raise ValueError("the shared shot budget must be an integer of at least 2")
        clean = {}
        for name, observable in self.targets.items():
            if (not isinstance(name, str) or not name.strip() or len(name) > 80
                    or any(ord(c) < 32 for c in name)):
                raise ValueError("target names must be nonempty strings of at most 80 characters, without controls")
            clean[name] = _validated_observable(observable, self.base.circuit.num_qubits)
        self.targets = clean

    @property
    def instance_id(self) -> str:
        return self.base.instance_id

    def target_instance(self, name: str) -> Instance:
        return replace(self.base, instance_id=f"{self.instance_id}::target:{name}",
                       observable=self.targets[name],
                       metadata={**self.base.metadata, "target_name": name,
                                 "bundle_instance_id": self.instance_id})

    def specification(self) -> dict[str, Any]:
        return {**self.base.specification(),
                "targets": {name: _observable_spec(op) for name, op in self.targets.items()},
                "shared_physical_shot_budget": int(self.base.shots)}


@dataclass
class BundlePlan:
    instance_id: str
    strategy: str
    allocation: str
    target_plans: dict[str, ExecutionPlan]
    targets: dict[str, list[list[Any]]]
    metadata: dict[str, Any] = field(default_factory=dict)

    def summary(self) -> dict[str, Any]:
        summaries = {name: plan.summary() for name, plan in self.target_plans.items()}
        return dict(instance_id=self.instance_id, strategy=self.strategy,
                    allocation=self.allocation, target_count=len(summaries),
                    experiments=sum(s["experiments"] for s in summaries.values()),
                    physical_shots=sum(s["physical_shots"] for s in summaries.values()),
                    maximum_experiment_width=max((s["maximum_experiment_width"] for s in summaries.values()), default=0),
                    shot_weighted_two_qubit_gates=sum(s["shot_weighted_two_qubit_gates"] for s in summaries.values()),
                    targets=summaries, **self.metadata)


def _constant_plan(instance: Instance, strategy: str, allocation: str) -> ExecutionPlan | None:
    terms = instance.observable.to_list()
    if any(c != 0 and set(p) != {"I"} for p, c in terms):
        return None
    return ExecutionPlan(instance.instance_id, strategy, "constant", allocation,
                         [], [], [], math.fsum(float(c.real) for _, c in terms),
                         dict(selected_strategy="constant", maximum_qpd_overhead=1.0,
                              gate_cuts=0, logical_fragment_widths=[], planning_seconds=0.0,
                              shot_allocation_min=0, shot_allocation_max=0))


def plan_bundle(instance: MultiObservableInstance, strategy: str = "policy",
                allocation: str = "coefficient", *, limits: Limits | None = None) -> BundlePlan:
    """Prepare all targets, then allocate the ONE budget across all experiments.

    The coefficient heuristic uses |observable coefficient * QPD coefficient|
    for each experiment. It is not a claim of optimal multi-output allocation.
    Candidate search is repeated per target; this favors a simple auditable
    interface over a cache that might hide target-dependent participant choices.
    """
    began = time.perf_counter()
    limits = limits or Limits()
    if strategy not in {"direct", "auto_cut", "structured_cut", "policy", "participant"}:
        raise ValueError("unknown strategy")
    if allocation not in {"equal", "coefficient"}:
        raise ValueError("allocation must be equal or coefficient")
    target_plans = {}
    all_experiments = []
    for name in instance.targets:
        target = instance.target_instance(name)
        prepared = _constant_plan(target, strategy, allocation)
        if prepared is None:
            if strategy == "participant":
                prepared = participant.build_plan(target, allocation, limits=limits)
            else:
                prepared = engine.plan(target, strategy, allocation, limits=limits)
        target_plans[name] = prepared
        all_experiments.extend(prepared.experiments)
        if len(all_experiments) > limits.max_experiments:
            raise InfeasiblePlan("combined targets exceed the global experiment-count cap")
    try:
        shots = allocate_shots([1.0 if allocation == "equal" else e.weight for e in all_experiments],
                               int(instance.base.shots), limits.min_shots_per_experiment)
    except ValueError as error:
        raise InfeasiblePlan(f"combined target allocation: {error}") from error
    for experiment, count in zip(all_experiments, shots):
        experiment.shots = count
    for name, prepared in target_plans.items():
        counts = [e.shots for e in prepared.experiments]
        prepared.metadata.update(shot_allocation_min=min(counts, default=0),
                                 shot_allocation_max=max(counts, default=0),
                                 bundle_target=name, allocation_scope="all targets jointly",
                                 shared_physical_shot_budget=int(instance.base.shots),
                                 allocated_target_shots=sum(counts))
    bundle = BundlePlan(instance.instance_id, strategy, allocation, target_plans,
                        {name: _observable_spec(op) for name, op in instance.targets.items()},
                        dict(planning_seconds=time.perf_counter()-began,
                             shared_physical_shot_budget=int(instance.base.shots),
                             max_experiments=limits.max_experiments,
                             measurement_reuse_across_targets=False,
                             allocation_scope="all targets jointly"))
    validate_bundle(instance, bundle)
    return bundle


def validate_bundle(instance: MultiObservableInstance, bundle: BundlePlan) -> None:
    """Preflight every target and the combined ledger before executing any target."""
    if instance.instance_id != bundle.instance_id:
        raise ValueError("bundle belongs to a different instance")
    expected = {name: _observable_spec(op) for name, op in instance.targets.items()}
    if bundle.targets != expected or list(bundle.target_plans) != list(instance.targets):
        raise ValueError("bundle targets differ from the requested targets")
    experiments = [e for p in bundle.target_plans.values() for e in p.experiments]
    if len(experiments) > bundle.metadata.get("max_experiments", Limits().max_experiments):
        raise InfeasiblePlan("combined targets exceed the global experiment-count cap")
    if sum(e.shots for e in experiments) > instance.base.shots:
        raise InfeasiblePlan("combined targets exceed the shared physical-shot budget")
    for name, prepared in bundle.target_plans.items():
        engine.validate_plan(instance.target_instance(name), prepared)


def execute_bundle(instance: MultiObservableInstance, bundle: BundlePlan, *, seed: int = 2026,
                   confidence: float = 0.95) -> dict[str, Any]:
    """Execute disjoint target experiments and return simultaneous intervals.

    Bonferroni assigns failure probability (1-confidence)/number_of_targets to
    each target's existing union-Hoeffding interval. This covers all noisy target
    estimands simultaneously under the documented fixed-allocation assumptions.
    """
    began = time.perf_counter()
    if not isinstance(confidence, numbers.Real) or not math.isfinite(confidence) or not 0 < confidence < 1:
        raise ValueError("confidence must be finite and strictly between zero and one")
    if isinstance(seed, bool) or not isinstance(seed, numbers.Integral) or seed < 0:
        raise ValueError("seed must be a nonnegative integer")
    validate_bundle(instance, bundle)
    count = len(bundle.target_plans)
    target_confidence = 1 - (1 - confidence) / count
    if target_confidence >= 1:
        raise ValueError("confidence is too close to one for target-wise Bonferroni allocation")
    # Preserve exact single-target equivalence with engine.execute.
    seeds = ([int(seed)] if count == 1 else
             [int(s.generate_state(1, dtype=np.uint32)[0])
              for s in np.random.SeedSequence(int(seed)).spawn(count)])
    results, total_used = {}, 0
    for (name, prepared), target_seed in zip(bundle.target_plans.items(), seeds):
        allocated = sum(e.shots for e in prepared.experiments)
        # Instance requires >=2 even for a known constant; no backend shots are
        # reserved in that case. Its externally reported allocation remains zero.
        target = replace(instance.target_instance(name), shots=max(2, allocated))
        result = engine.execute(target, prepared, seed=target_seed, confidence=target_confidence)
        if result["physical_shots"] != allocated:
            raise RuntimeError("target execution disagrees with its allocated physical-shot count")
        total_used += result["physical_shots"]
        if total_used > instance.base.shots:
            raise RuntimeError("combined execution exceeded the physical-shot budget")
        result.update(target_name=name, shot_budget=allocated,
                      observable=_observable_spec(instance.targets[name]),
                      shared_physical_shot_budget=int(instance.base.shots))
        results[name] = result
    return dict(instance_id=instance.instance_id, seed=int(seed), targets=results,
                physical_shots=total_used, shot_budget=int(instance.base.shots),
                unused_physical_shots=int(instance.base.shots)-total_used,
                confidence=float(confidence), target_confidence=float(target_confidence),
                simultaneous_interval_method="Bonferroni across targets; union-Hoeffding within each target; fixed allocation; noisy estimands",
                uncertainty_warning="Simultaneous sampling intervals exclude hardware bias; plug-in standard errors are approximate.",
                qiskit_reconstruction_agrees=all(r["qiskit_reconstruction_agrees"] for r in results.values()),
                plan=bundle.summary(), execution_seconds=time.perf_counter()-began)
