"""Organizer-only ideal reference. Do not use inside participant planners."""
from qiskit.quantum_info import Statevector
from .instances import Instance


def ideal_reference(instance: Instance) -> float:
    return float(Statevector.from_instruction(instance.circuit).expectation_value(instance.observable).real)
