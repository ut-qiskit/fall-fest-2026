"""Matched diagnostic suites: change one resource/backend axis at a time."""
from __future__ import annotations
from dataclasses import asdict, replace
from copy import deepcopy
import hashlib
import io
import json
from pathlib import Path
from typing import Sequence
from qiskit import qpy
from .benchmark import BenchmarkCase, load_suite, save_suite, file_hash
from .bundle import MultiObservableInstance
from .instances import HardwareProfile, _finite, _integer


AXES = ("topology", "noise", "width", "shots")
FAMILIES = ("qaoa", "spin", "variational", "modular")


def circuit_hash(circuit) -> str:
    """Hash exact QPY bytes in the pinned environment, including circuit metadata."""
    stream = io.BytesIO()
    qpy.dump(circuit, stream)
    return hashlib.sha256(stream.getvalue()).hexdigest()


def targets_hash(targets) -> str:
    # Preserve target order because it determines allocation rounding and seeds.
    record = [[name, [[label, float(weight.real)] for label, weight in op.to_list()]]
              for name, op in targets.items()]
    return hashlib.sha256(json.dumps(record, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _values_for(axis, source, values):
    if values is None:
        if axis == "topology":
            values = ["line", "ring", "all_to_all"]
        elif axis == "noise":
            values = [0.0, 1.0, 2.0]
        elif axis == "width":
            n = source.circuit.num_qubits
            values = list(dict.fromkeys([max(1,n//2), n, min(10,n+2)]))
        else:
            values = list(dict.fromkeys([max(2,source.shots//2), source.shots, 2*source.shots]))
    if isinstance(values, (str, bytes)) or not values:
        raise ValueError("values must be a nonempty sequence")
    clean = []
    for value in values:
        if axis == "topology":
            if value not in {"line", "ring", "all_to_all"}:
                raise ValueError("topology values must be line, ring, or all_to_all")
        elif axis == "noise":
            value = _finite(value, "noise scale", 0.0, 10.0)
        elif axis == "width":
            value = _integer(value, "width", 1, 10)
        else:
            value = _integer(value, "shots", 2)
        clean.append(value)
    if len(set(clean)) != len(clean):
        raise ValueError("condition values must be distinct")
    if axis == "noise" and any(value != 1 for value in clean):
        if not any((source.hardware.one_qubit_error, source.hardware.two_qubit_error, source.hardware.readout_error)):
            raise ValueError("scaling an ideal source cannot change noise; choose a source with nonzero rates")
    return clean


def make_matched_cases(cases: Sequence[BenchmarkCase], *, axis: str = "topology",
                       values: Sequence | None = None, per_family: int = 1,
                       families: Sequence[str] | None = None) -> list[BenchmarkCase]:
    """Clone exact circuits/targets and vary only the selected experimental axis.

    Select required, direct-feasible source cases, ordered by case_id, up to
    per_family from each requested family. Defaults select all four challenge
    families. Other source strata (including controls/stresses) are not silently
    substituted. Noise scales all three source rates together, holding their
    ratio fixed; it is one model-strength axis, not an isolated gate-error sweep.

    A width sweep may make direct execution unavailable or cutting infeasible.
    Such outcomes are valid diagnostic observations; no cap is relaxed here.
    """
    if axis not in AXES:
        raise ValueError(f"axis must be one of {AXES}")
    per_family = _integer(per_family, "per_family", 1)
    families = list(FAMILIES if families is None else families)
    if not families or len(set(families)) != len(families) or any(family not in FAMILIES for family in families):
        raise ValueError("families must be a nonempty selection of distinct challenge families")
    selected = []
    for family in families:
        eligible = sorted([case for case in cases if case.required and case.instance.base.family == family
                            and case.instance.base.circuit.num_qubits <= case.instance.base.max_width],
                           key=lambda case: case.case_id)
        if len(eligible) < per_family:
            raise ValueError(f"need {per_family} required direct-feasible source cases for {family}")
        selected.extend(eligible[:per_family])
    output = []
    for source_case in selected:
        source = source_case.instance.base
        original_hardware = asdict(source.hardware)
        source_circuit_hash = circuit_hash(source.circuit)
        source_targets_hash = targets_hash(source_case.instance.targets)
        for value in _values_for(axis, source, values):
            hardware = dict(original_hardware)
            width, shots = source.max_width, source.shots
            changed = []
            if axis == "topology":
                hardware["topology"] = value
            elif axis == "noise":
                for key in ("one_qubit_error", "two_qubit_error", "readout_error"):
                    hardware[key] = original_hardware[key] * value
            elif axis == "width":
                width = value
            else:
                shots = value
            for key in original_hardware:
                if hardware[key] != original_hardware[key]:
                    changed.append(f"hardware.{key}")
            if width != source.max_width:
                changed.append("max_width")
            if shots != source.shots:
                changed.append("shots")
            profile = HardwareProfile(**hardware)
            label = str(value) if not isinstance(value, float) else format(value, ".8g")
            condition = dict(source_case=source_case.case_id, source_instance=source.instance_id,
                             circuit_sha256=source_circuit_hash, targets_sha256=source_targets_hash,
                             axis=axis, value=value, hardware=hardware, width=width, shots=shots)
            fingerprint = hashlib.sha256(json.dumps(condition, sort_keys=True,
                 separators=(",", ":"), allow_nan=False).encode()).hexdigest()[:16]
            metadata = deepcopy(source.metadata)
            metadata.update(generator_fingerprint=source.metadata.get("fingerprint"),
                fingerprint=fingerprint, paired_source_case=source_case.case_id,
                paired_source_instance=source.instance_id, paired_circuit_sha256=source_circuit_hash,
                paired_targets_sha256=source_targets_hash, changed_fields=changed,
                matched_axis=axis, matched_value=value,
                paired_source_conditions=dict(hardware=original_hardware, max_width=source.max_width, shots=source.shots),
                diagnostic_only=True)
            base = replace(source, instance_id=f"{source.instance_id}--{axis}-{label}-{fingerprint}",
                           circuit=source.circuit.copy(), observable=source.observable.copy(),
                           max_width=width, shots=shots, hardware=profile, metadata=metadata)
            targets = {name: op.copy() for name, op in source_case.instance.targets.items()}
            if circuit_hash(base.circuit) != source_circuit_hash or targets_hash(targets) != source_targets_hash:
                raise RuntimeError("matched-condition cloning altered circuit or targets")
            output.append(BenchmarkCase(f"{source_case.case_id}--matched-{axis}-{label}-{fingerprint[:8]}",
                MultiObservableInstance(base, targets), source_case.split,
                f"{source.family}/matched-{axis}", source_case.required))
    return output


def save_matched_suite(manifest: Path, output: Path, *, axis: str = "topology",
                       values: Sequence | None = None, per_family: int = 1,
                       families: Sequence[str] | None = None) -> Path:
    """Load/export benchmark v2, preserving private suite separation."""
    manifest, output = Path(manifest).resolve(), Path(output).resolve()
    cases = load_suite(manifest)
    root = Path(__file__).resolve().parents[2]
    if any(case.split == "private" for case in cases) and output.is_relative_to(root):
        raise ValueError("private matched-condition suites must stay outside the distributable toolkit")
    generated = make_matched_cases(cases, axis=axis, values=values, per_family=per_family, families=families)
    return save_suite(generated, output, provenance=dict(
        source="matched-condition diagnostic v1", diagnostic_only=True, axis=axis,
        source_manifest_name=manifest.name, source_manifest_sha256=file_hash(manifest),
        values=list(values) if values is not None else "axis defaults", per_family=per_family,
        families=list(families) if families is not None else list(FAMILIES),
        warning="Circuit and targets are fixed within each source-case group. Width/resource sweeps can validly make a method infeasible."))
