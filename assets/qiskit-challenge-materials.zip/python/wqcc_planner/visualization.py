"""Export an actual prepared plan as auditable JSON and a standalone SVG.

No illustrative cut or mapping is inferred: engine trace fields and compiled
layouts are the source. The JSON contains every experiment and reconstruction
product; the SVG is a readable, vertically scrolling report of the same plan.
"""
from __future__ import annotations

from collections import defaultdict
from html import escape
import json
from pathlib import Path
import re
import textwrap
from typing import Any

import numpy as np

from .bundle import BundlePlan, MultiObservableInstance, validate_bundle


def _json_value(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _json_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(v) for v in value]
    if isinstance(value, np.generic):
        return value.item()
    return value


def plan_document(instance: MultiObservableInstance, bundle: BundlePlan) -> dict[str, Any]:
    """Return circuit, chosen cuts, physical mappings, allocation, and products."""
    validate_bundle(instance, bundle)
    circuit = instance.base.circuit
    input_instructions = [dict(index=i, gate=instruction.operation.name,
                               qubits=[circuit.find_bit(q).index for q in instruction.qubits],
                               parameters=[float(p) for p in instruction.operation.params])
                          for i, instruction in enumerate(circuit.data)]
    targets = {}
    global_index = 0
    for name, prepared in bundle.target_plans.items():
        associations = {i: dict(pauli=term.pauli,
                                observable_coefficient=term.observable_coefficient)
                        for term in prepared.terms for ids in term.experiment_indices.values() for i in ids}
        experiments = []
        for index, experiment in enumerate(prepared.experiments):
            logical = list(experiment.logical_qubits)
            initial = list(experiment.initial_physical_layout)
            final = list(experiment.final_physical_layout)
            physical_mapping = [dict(logical_qubit=q,
                                     initial_physical_qubit=initial[j] if j < len(initial) else None,
                                     final_physical_qubit=final[j] if j < len(final) else None)
                                for j, q in enumerate(logical)]
            experiments.append(dict(experiment=index, global_experiment=global_index,
                                    target=name, term=experiment.term,
                                    qpd_term=experiment.qpd_term, partition=str(experiment.partition),
                                    shots=experiment.shots, allocation_weight=experiment.weight,
                                    parity_mask=experiment.parity_mask,
                                    logical_qubits=logical, initial_physical_layout=initial,
                                    final_physical_layout=final, physical_mapping=physical_mapping,
                                    compiled_width=experiment.circuit.num_qubits,
                                    compiled_depth=experiment.circuit.depth(),
                                    compiled_two_qubit_depth=experiment.circuit.depth(lambda i: len(i.qubits) == 2),
                                    compiled_operations=dict(experiment.circuit.count_ops()),
                                    **associations[index]))
            global_index += 1
        targets[name] = dict(observable=bundle.targets[name], constant=prepared.constant,
                             decision=prepared.decision, summary=prepared.summary(),
                             cut_locations=prepared.metadata.get("cut_locations", []),
                             partition_map=prepared.metadata.get("partition_map", {}),
                             trace_available=bool(prepared.metadata.get("partition_map")) or not experiments,
                             physical_edges=prepared.metadata.get("physical_edges", []),
                             experiments=experiments,
                             reconstruction_products=[dict(coefficient=float(c), experiments=indices)
                                                      for c, indices in prepared.products])
    return _json_value(dict(schema_version="wqcc-execution-plan-1",
                            instance=instance.specification(), plan=bundle.summary(),
                            input_circuit=dict(qubits=circuit.num_qubits, instructions=input_instructions),
                            targets=targets,
                            interpretation="Mappings and cuts are from the selected compiled plans. Fragment physical labels identify separate circuit runs, not concurrent hardware occupancy. QPD sign bits are included in parity_mask. This is a prepared plan, not evidence of execution."))


def render_plan_svg(document: dict[str, Any], path: str | Path, *, max_experiment_rows: int | None = None) -> Path:
    """Render every experiment by default; an explicit cap is labeled in the SVG."""
    if max_experiment_rows is not None and max_experiment_rows < 1:
        raise ValueError("max_experiment_rows must be positive or None")
    width, margin, y = 1440, 40, 48
    body = []
    palette = ["#8A3FFC", "#0F62FE", "#D02670"]

    def text(x: int, at_y: float, content: Any, size: int = 18, color: str = "#161616", weight: str = "400") -> None:
        body.append(f'<text x="{x}" y="{at_y:g}" font-size="{size}" fill="{color}" font-weight="{weight}">{escape(str(content))}</text>')

    def lines(content: str, *, color: str = "#525252", columns: int = 132, size: int = 17) -> None:
        nonlocal y
        for line in textwrap.wrap(content, columns, break_long_words=True, break_on_hyphens=False) or [""]:
            text(margin, y, line, size, color)
            y += 25

    def rule() -> None:
        body.append(f'<line x1="{margin}" y1="{y}" x2="{width-margin}" y2="{y}" stroke="#c6c6c6"/>')

    text(margin, y, "Execution plan", 34)
    y += 38
    lines(document["instance"]["instance_id"], size=19, columns=118)
    summary = document["plan"]
    lines(f'{summary["target_count"]} targets | {summary["experiments"]} physical experiments | '
          f'{summary["physical_shots"]:,} / {document["instance"]["shared_physical_shot_budget"]:,} allocated shots | '
          f'{summary["allocation"]} allocation | requested strategy: {summary["strategy"]}')
    lines(f'Input circuit: {document["input_circuit"]["qubits"]} logical qubits, '
          f'{len(document["input_circuit"]["instructions"])} instructions. '
          f'Backend topology: {document["instance"]["hardware"]["topology"]}; '
          f'physical width limit: {document["instance"]["max_width"]}.')
    lines("Logical q labels refer to the original circuit. Initial and final p labels come from each compiled layout. "
          "Fragments run as separate experiments. Exact input instructions and reconstruction products are in the companion JSON.")
    y += 12
    for target_index, (name, target) in enumerate(document["targets"].items()):
        color = palette[target_index % len(palette)]
        rule()
        y += 38
        text(margin, y, name, 27, color)
        y += 32
        target_summary = target["summary"]
        lines(f'Decision: {target["decision"]}; selected strategy: {target_summary.get("selected_strategy", "unknown")}; '
              f'{len(target["experiments"])} experiments; {target_summary["physical_shots"]:,} shots; constant offset {target["constant"]:g}.')
        lines("Observable: " + " + ".join(f"({c:g}) {p}" for p, c in target["observable"]), color="#161616")
        if not target["experiments"]:
            lines("This target is known exactly. No cut search, hardware mapping, or physical shots are required.")
            y += 14
            continue
        partitions = target["partition_map"]
        lines("Logical fragments: " + ("; ".join(f'{label}: ' + ", ".join(f"q{q}" for q in qubits)
                                                       for label, qubits in partitions.items()) or "trace unavailable"))
        if target["cut_locations"]:
            lines("Selected gate cuts:", color=color)
            for cut in target["cut_locations"]:
                parameters = ", ".join(f"{p:.5g}" for p in cut["parameters"])
                lines(f'Instruction {cut["instruction_index"]}: {cut["gate"]}({parameters}) on '
                      + ", ".join(f"q{q}" for q in cut["qubits"]))
        else:
            lines("Selected gate cuts: none.")
        groups = defaultdict(lambda: [0, 0])
        for experiment in target["experiments"]:
            key = (experiment["partition"], tuple(experiment["logical_qubits"]),
                   tuple(experiment["initial_physical_layout"]), tuple(experiment["final_physical_layout"]))
            groups[key][0] += 1
            groups[key][1] += experiment["shots"]
        y += 5
        lines("Compiled mappings (logical → initial physical → final physical):", color=color)
        for (partition, logical, initial, final), (count, shots) in groups.items():
            triples = [f"q{q} → p{initial[i] if i < len(initial) else '?'} → p{final[i] if i < len(final) else '?'}"
                       for i, q in enumerate(logical)]
            lines(f'Fragment {partition}: ' + ("; ".join(triples) or "trace unavailable")
                  + f" | {count} experiments, {shots:,} shots")
        y += 10
        headers = [(margin, "Global / local ID"), (235, "Pauli"), (455, "QPD term"),
                   (615, "Fragment"), (765, "Shots"), (925, "Width"), (1080, "2q depth")]
        for x, label in headers:
            text(x, y, label, 17, color, "500")
        y += 13
        rule()
        y += 26
        shown = target["experiments"] if max_experiment_rows is None else target["experiments"][:max_experiment_rows]
        for row in shown:
            values = [(margin, f'{row["global_experiment"]} / {row["experiment"]}'),
                      (235, row["pauli"]), (455, row["qpd_term"]), (615, row["partition"]),
                      (765, f'{row["shots"]:,}'), (925, row["compiled_width"]),
                      (1080, row["compiled_two_qubit_depth"])]
            for x, value in values:
                text(x, y, value, 17)
            y += 28
        if len(shown) < len(target["experiments"]):
            lines(f'Showing {len(shown)} of {len(target["experiments"])} experiments for this target. '
                  "The companion JSON contains every experiment and exact shot allocation.")
        y += 18
    rule()
    y += 32
    lines("Prepared-plan trace, generated by WQCC's execution-planner toolkit. No reference-oracle values or sampled outcomes enter this report.")
    height = int(y + 28)
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
           f'viewBox="0 0 {width} {height}" role="img" aria-labelledby="title desc">'
           '<title id="title">Actual multi-observable execution plan</title>'
           '<desc id="desc">Selected cuts, original-qubit fragments, compiled hardware mappings, '
           'and physical shots for each named target and experiment.</desc>'
           f'<rect width="{width}" height="{height}" fill="white"/>'
           '<g font-family="IBM Plex Sans, DejaVu Sans, Arial, sans-serif">' + "".join(body) + '</g></svg>')
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(svg, encoding="utf-8")
    return output


def write_plan_artifacts(instance: MultiObservableInstance, bundle: BundlePlan,
                         output_dir: str | Path, stem: str | None = None) -> dict[str, str]:
    """Write a JSON audit record and self-contained SVG; return their paths."""
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    stem = stem or f"{instance.instance_id}-{bundle.strategy}-{bundle.allocation}"
    stem = re.sub(r"[^A-Za-z0-9_.-]+", "-", stem).strip(".-")[:180] or "execution-plan"
    document = plan_document(instance, bundle)
    json_path, svg_path = output / f"{stem}.json", output / f"{stem}.svg"
    json_path.write_text(json.dumps(document, indent=2, allow_nan=False), encoding="utf-8")
    render_plan_svg(document, svg_path)
    return {"json": str(json_path), "svg": str(svg_path)}
