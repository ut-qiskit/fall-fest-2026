"""Portable command line entry point; no credentials or QPU account needed."""
from __future__ import annotations
import argparse
import csv
import importlib.metadata
import json
from pathlib import Path
import platform
import sys
import numpy as np
from qiskit import qpy
from . import make_instance, plan, execute, ideal_reference, InfeasiblePlan, Instance, HardwareProfile
from qiskit.quantum_info import SparsePauliOp
from .participant import build_plan


def prepare_mode(instance, mode, allocation):
    """Evaluation routes participant mode through the editable submission hook."""
    return build_plan(instance, allocation) if mode == "participant" else plan(instance, mode, allocation)


def environment():
    return {"python": platform.python_version(), "platform": platform.platform(),
            "packages": {p: importlib.metadata.version(p) for p in
                         ("qiskit", "qiskit-aer", "qiskit-addon-cutting", "numpy", "scipy")}}


def json_default(value):
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(type(value).__name__)


def write_json(path: Path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(content, indent=2, default=json_default, allow_nan=False), encoding="utf-8")


def run_demo(args):
    cases = [dict(family="product", max_width=4, noise="ideal"),
             dict(family="modular", max_width=2, noise="ideal"),
             dict(family="qaoa", max_width=4, noise="stressed")]
    runs = []
    for case in cases:
        instance = make_instance(**case, seed=17, shots=args.shots)
        for mode in ("direct", "auto_cut", "structured_cut", "policy"):
            for allocation in ("equal", "coefficient"):
                record = {"instance": instance.specification(), "mode": mode, "allocation": allocation}
                try:
                    prepared = prepare_mode(instance, mode, allocation)
                    result = execute(instance, prepared, seed=2026)
                    reference = ideal_reference(instance)
                    result.update(ideal_expectation=reference, absolute_error=abs(result["estimate"]-reference),
                                  squared_error=(result["estimate"]-reference)**2)
                    record.update(status="ok", result=result)
                    print(f"{instance.instance_id:35} {mode:14} {allocation:11} "
                          f"estimate={result['estimate']:+.4f} ideal={reference:+.4f} shots={result['physical_shots']}", flush=True)
                except InfeasiblePlan as error:
                    record.update(status="infeasible", reason=str(error))
                    print(f"{instance.instance_id} {mode}: infeasible ({error})", flush=True)
                runs.append(record)
    write_json(Path(args.output), {"environment": environment(),
               "scope": "One sampled replicate per strategy/allocation. Illustrative, not performance ranking.", "runs": runs})


def evaluation_specs(quick=False):
    specs = []
    for family in ("modular", "qaoa", "spin", "variational", "product"):
        for width, noise in ((2, "ideal"), (4, "mild")):
            specs.append(dict(family=family, n_qubits=4, max_width=width,
                              noise=noise, seed=17, split="public"))
    if not quick:
        for family in ("modular", "qaoa"):
            for width, noise in ((3, "mild"), (6, "stressed")):
                specs.append(dict(family=family, n_qubits=6, max_width=width,
                                  noise=noise, seed=101, split="disclosed_validation"))
    return specs


def run_evaluation(args):
    rows = []
    for instance, split in evaluation_instances(args):
        reference = ideal_reference(instance)
        for mode in args.modes.split(","):
            for allocation in ("equal", "coefficient"):
                base = dict(instance_id=instance.instance_id, family=instance.family,
                            circuit_seed=instance.seed, n_qubits=instance.circuit.num_qubits,
                            split=split, max_width=instance.max_width, noise=instance.hardware.name,
                            topology=instance.hardware.topology,
                            one_qubit_error=instance.hardware.one_qubit_error,
                            two_qubit_error=instance.hardware.two_qubit_error,
                            readout_error=instance.hardware.readout_error,
                            shot_budget=args.shots, mode=mode, allocation=allocation,
                            ideal_expectation=reference)
                try:
                    prepared = prepare_mode(instance, mode, allocation)
                except InfeasiblePlan as error:
                    rows.append(dict(**base, status="infeasible", reason=str(error)))
                    continue
                summary = prepared.summary()
                for replicate in range(args.replicates):
                    sampling_seed = 2026 + replicate
                    result = execute(instance, prepared, seed=sampling_seed)
                    low, high = result["sampling_interval"]
                    rows.append(dict(**base, status="ok", replicate=replicate, seed=sampling_seed,
                        decision=prepared.decision, budget_used=result["physical_shots"],
                        total_experiments=summary["experiments"],
                        max_fragment_width=summary["maximum_experiment_width"],
                        gamma2=summary["maximum_qpd_overhead"],
                        two_qubit_depth=summary["maximum_two_qubit_depth"],
                        shot_weighted_two_qubit_gates=summary["shot_weighted_two_qubit_gates"],
                        estimate=result["estimate"], standard_error_approx=result["sampling_standard_error_approx"],
                        interval_lower=low, interval_upper=high,
                        interval_target="noisy reconstructed estimand", interval_method="union-Hoeffding",
                        confidence=result["confidence"],
                        absolute_error=abs(result["estimate"]-reference),
                        squared_error=(result["estimate"]-reference)**2,
                        planning_seconds=summary["planning_seconds"],
                        execution_seconds=result["execution_seconds"]))
                print(f"Completed {instance.instance_id} {mode}/{allocation}", flush=True)
    prefix = Path(args.output)
    prefix.parent.mkdir(parents=True, exist_ok=True)
    write_json(prefix.with_suffix(".json"), dict(environment=environment(),
        warning="Each replicate receives the full stated budget; repetitions characterize variability and are not pooled into one budget-limited answer. Disclosed validation seeds are not a secret evaluation set.",
        rows=rows))
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with prefix.with_suffix(".csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {len(rows)} rows to {prefix}.csv and .json", flush=True)


def evaluation_instances(args):
    if args.manifest:
        manifest_path = Path(args.manifest).resolve()
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for spec in manifest["instances"]:
            circuit_path = (manifest_path.parent / spec["circuit_file"]).resolve()
            if not circuit_path.is_relative_to(manifest_path.parent):
                raise ValueError("manifest circuit files must stay within the manifest directory")
            with circuit_path.open("rb") as stream:
                circuits = qpy.load(stream)
            if len(circuits) != 1:
                raise ValueError("each manifest QPY file must contain exactly one circuit")
            instance = Instance(spec["instance_id"], circuits[0],
                SparsePauliOp.from_list(spec["observable"]), spec["max_width"], args.shots,
                HardwareProfile(**spec["hardware"]), spec["seed"], spec["family"], spec["metadata"])
            yield instance, spec.get("split", "public")
    else:
        for specification in evaluation_specs(args.quick):
            spec = dict(specification)
            split = spec.pop("split")
            yield make_instance(**spec, shots=args.shots), split


def run_generate(args):
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    specs = []
    seeds = [int(value) for value in args.seeds.split(",")]
    for seed in seeds:
        for family in args.families.split(","):
            instance = make_instance(family, n_qubits=args.qubits, seed=seed,
                                    max_width=args.width, shots=args.shots, noise=args.noise)
            filename = f"{instance.instance_id}.qpy"
            with (output / filename).open("wb") as stream:
                qpy.dump(instance.circuit, stream)
            specs.append(dict(**instance.specification(), circuit_file=filename,
                              split=args.split))
    write_json(output / "manifest.json", dict(environment=environment(),
        warning="All distributed seeds are public. Reserve fresh seeds privately for a future organizer evaluation.", instances=specs))
    print(f"Saved {len(specs)} QPY circuits and manifest to {output}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    demo = commands.add_parser("demo", help="three teaching cases; reports honest infeasible direct baseline")
    demo.add_argument("--shots", type=int, default=12000)
    demo.add_argument("--output", default="results/demo.json")
    demo.set_defaults(func=run_demo)
    evaluate = commands.add_parser("evaluate", help="small reproducible suite, repeated independent sampling")
    evaluate.add_argument("--shots", type=int, default=12000)
    evaluate.add_argument("--replicates", type=int, default=3)
    evaluate.add_argument("--modes", default="direct,auto_cut,structured_cut,policy")
    evaluate.add_argument("--manifest", help="evaluate a generator manifest instead of the bundled scenario definitions")
    evaluate.add_argument("--quick", action="store_true", help="omit six-qubit disclosed validation cases")
    evaluate.add_argument("--output", default="results/benchmark")
    evaluate.set_defaults(func=run_evaluation)
    generate = commands.add_parser("generate", help="export public circuit instances and their exact specifications")
    generate.add_argument("--families", default="modular,qaoa,spin,variational,product")
    generate.add_argument("--seeds", default="17,29")
    generate.add_argument("--qubits", type=int, default=4)
    generate.add_argument("--width", type=int, default=2)
    generate.add_argument("--shots", type=int, default=12000)
    generate.add_argument("--noise", choices=["ideal", "mild", "stressed"], default="ideal")
    generate.add_argument("--split", default="public")
    generate.add_argument("--output", default="data/public")
    generate.set_defaults(func=run_generate)
    args = parser.parse_args()
    if args.shots < 2 or (hasattr(args, "replicates") and args.replicates < 1):
        parser.error("shots must be at least 2 and replicates positive")
    args.func(args)


if __name__ == "__main__":
    main()
