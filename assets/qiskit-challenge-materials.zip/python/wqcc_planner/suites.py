"""Deterministic suite specifications; no private data is written here.

The caller owns storage/access separation. Labeling a generated suite private
does not hide its seed or specimens from anyone who receives that suite.
"""
from __future__ import annotations
import hashlib
import numpy as np
from .instances import _integer


SPLITS = ("public", "validation", "private")


def suite_specs(split: str, master_seed: int, preset: str = "smoke") -> list[dict]:
    """Return JSON-safe case records with kwargs, split, stratum, required, case_id.

    smoke: 8 required family/feasibility cases + 2 analytic controls (10 total).
    standard: two draws for each family/feasibility case, 2 controls, and 2
    optional expansion stresses (20 total). Required width-limited cases use
    two modules joined by one interaction per layer, with one layer. Required
    feasibility is calibrated for the package's bounded auto-cut baseline;
    arbitrary extensions still need explicit calibration.

    Public uses four qubits, validation six, private eight. Backend
    conditions change by split. Specify a fresh, privately held master seed for
    a genuinely hidden organizer suite and keep generated outputs private.
    """
    if split not in SPLITS:
        raise ValueError(f"split must be one of {SPLITS}")
    if preset not in {"smoke", "standard"}:
        raise ValueError("preset must be smoke or standard")
    master_seed = _integer(master_seed, "master_seed", 0)
    split_index = SPLITS.index(split)
    n = (4, 6, 8)[split_index]
    # Independent namespaces prevent accidental reuse across split or preset.
    namespace = int.from_bytes(hashlib.sha256(f"wqcc-suite-v2:{split}:{preset}".encode()).digest()[:4], "little")
    rng = np.random.default_rng(np.random.SeedSequence([master_seed, namespace]))
    cases = []
    seen_seeds = set()

    def next_seed():
        while True:
            value = int(rng.integers(0, 2**31))
            if value not in seen_seeds:
                seen_seeds.add(value)
                return value

    def hardware(draw, control=False):
        if control:
            return {"name": "ideal-control", "topology": "line", "one_qubit_error": 0.0,
                    "two_qubit_error": 0.0, "readout_error": 0.0}
        return {
            "name": f"synthetic-{split}-{draw}",
            "topology": ("line", "ring", "all_to_all")[(split_index + draw) % 3],
            "one_qubit_error": (0.0004, 0.0008, 0.0012)[split_index] * (1 + 0.2*draw),
            "two_qubit_error": (0.008, 0.015, 0.023)[split_index] * (1 + 0.15*draw),
            "readout_error": (0.003, 0.006, 0.009)[split_index] * (1 + 0.1*draw),
        }

    repetitions = 1 if preset == "smoke" else 2
    for family_index, family in enumerate(("qaoa", "spin", "variational", "modular")):
        for regime in ("direct-feasible", "width-constrained"):
            for draw in range(repetitions):
                constrained = regime == "width-constrained"
                graph = "modular" if constrained or family == "modular" else ("tree", "ring", "star")[(family_index+draw+split_index) % 3]
                case_id = f"{split}-{family}-{regime}-{draw}"
                kwargs = dict(family=family, generator_version=2, n_qubits=n, seed=next_seed(),
                              layers=1 if constrained else 1+draw, max_width=n//2 if constrained else n,
                              shots=24000, graph=graph, module_size=n//2, weighted=True,
                              relabel=True, disorder=(0.25, 0.4, 0.55)[split_index],
                              coupling_strength=1.0, hardware=hardware(draw))
                cases.append(dict(kwargs=kwargs, split=split, stratum=f"{family}/{regime}",
                                  required=True, case_id=case_id))
    for state in ("zero", "alternating"):
        cases.append(dict(kwargs=dict(family="product", generator_version=2, n_qubits=n,
             seed=next_seed(), max_width=n, shots=24000, product_state=state, relabel=True,
             hardware=hardware(0, control=True)), split=split, stratum="product/no-cut-control",
             required=True, case_id=f"{split}-product-{state}"))
    if preset == "standard":
        for family in ("qaoa", "variational"):
            cases.append(dict(kwargs=dict(family=family, generator_version=2, n_qubits=n,
                 seed=next_seed(), max_width=2, shots=24000, graph="ring", layers=3,
                 weighted=True, relabel=True, hardware=hardware(1)), split=split,
                 stratum=f"{family}/optional-stress", required=False,
                 case_id=f"{split}-{family}-optional-stress"))
    return cases

