"""Small procedural workloads and explicit synthetic hardware profiles."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
import hashlib
import json
import math
from numbers import Integral, Real
from typing import Any
import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import SparsePauliOp


def _integer(value: Any, name: str, minimum: int, maximum: int | None = None) -> int:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Integral):
        raise ValueError(f"{name} must be an integer")
    value = int(value)
    if value < minimum or (maximum is not None and value > maximum):
        raise ValueError(f"{name} must be in [{minimum}, {maximum if maximum is not None else 'infinity'}]")
    return value


def _finite(value: Any, name: str, minimum: float, maximum: float) -> float:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Real) or not math.isfinite(value):
        raise ValueError(f"{name} must be a finite real number")
    value = float(value)
    if not minimum <= value <= maximum:
        raise ValueError(f"{name} must be in [{minimum}, {maximum}]")
    return value


@dataclass(frozen=True)
class HardwareProfile:
    name: str = "ideal"
    topology: str = "line"
    one_qubit_error: float = 0.0
    two_qubit_error: float = 0.0
    readout_error: float = 0.0

    def __post_init__(self):
        if not isinstance(self.name, str) or not self.name:
            raise ValueError("hardware name must be a nonempty string")
        if self.topology not in {"line", "ring", "all_to_all"}:
            raise ValueError("topology must be line, ring, or all_to_all")
        for name in ("one_qubit_error", "two_qubit_error", "readout_error"):
            object.__setattr__(self, name, _finite(getattr(self, name), name, 0, 0.1))

    def edges(self, width: int) -> list[list[int]]:
        width = _integer(width, "width", 1)
        if self.topology == "all_to_all":
            return [[a, b] for a in range(width) for b in range(width) if a != b]
        pairs = [(a, a + 1) for a in range(width - 1)]
        if self.topology == "ring" and width > 2:
            pairs.append((0, width - 1))
        return [[a, b] for a, b in pairs] + [[b, a] for a, b in pairs]


PROFILES = {
    "ideal": HardwareProfile(),
    "mild": HardwareProfile("mild", "line", 0.0005, 0.01, 0.005),
    "stressed": HardwareProfile("stressed", "line", 0.002, 0.035, 0.015),
}


@dataclass
class Instance:
    instance_id: str
    circuit: QuantumCircuit
    observable: SparsePauliOp
    max_width: int
    shots: int
    hardware: HardwareProfile
    seed: int
    family: str
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.max_width = _integer(self.max_width, "max_width", 1)
        self.shots = _integer(self.shots, "shots", 2)
        self.seed = _integer(self.seed, "seed", 0)
        if not isinstance(self.hardware, HardwareProfile):
            raise ValueError("hardware must be a HardwareProfile")
        if self.circuit.num_qubits != self.observable.num_qubits:
            raise ValueError("observable and circuit widths must agree")
        if self.circuit.num_clbits or self.circuit.parameters:
            raise ValueError("input must be a bound circuit without classical bits")
        if not np.all(np.isfinite(self.observable.coeffs)):
            raise ValueError("observable coefficients must be finite")
        if any(abs(x.imag) > 1e-12 for x in self.observable.coeffs):
            raise ValueError("only Hermitian Pauli sums with real coefficients supported")
        if sum(abs(x) for x in self.observable.coeffs) > 1.00000001:
            raise ValueError("normalize sum of absolute Pauli coefficients to <= 1")
        if any(i.operation.name in {"measure", "reset"} for i in self.circuit.data):
            raise ValueError("input circuit must be unitary; fragment resets are generated later")
        for instruction in self.circuit.data:
            for parameter in instruction.operation.params:
                if isinstance(parameter, (Real, complex)) and not np.isfinite(parameter):
                    raise ValueError("circuit gate parameters must be finite")

    def specification(self) -> dict[str, Any]:
        return dict(instance_id=self.instance_id, family=self.family, seed=self.seed,
                    n_qubits=self.circuit.num_qubits, max_width=self.max_width,
                    shots=self.shots, hardware=asdict(self.hardware),
                    observable=[(p, float(c.real)) for p, c in self.observable.to_list()],
                    metadata=self.metadata)


def pauli_label(n: int, positions: dict[int, str]) -> str:
    """Qiskit labels place qubit 0 on the RIGHT."""
    label = ["I"] * n
    for qubit, operator in positions.items():
        label[n - 1 - qubit] = operator
    return "".join(label)


def _make_instance_v1(family: str = "modular", *, n_qubits: int = 4, seed: int = 17,
                  max_width: int = 2, shots: int = 12000, noise: str = "ideal",
                  layers: int = 1, topology: str | None = None) -> Instance:
    """Generate one bound circuit and normalized Pauli-sum target.

    A shallow line interaction graph keeps small examples practical. Increasing
    layers adds cross-partition cuts and can deliberately exceed plan caps.
    The modular family applies controlled RY gates between modules. All families
    are intentionally small simulation workloads, not industrial benchmarks.
    """
    if family not in {"modular", "qaoa", "spin", "variational", "product"}:
        raise ValueError("family must be modular, qaoa, spin, variational, or product")
    if not 2 <= n_qubits <= 10 or not 1 <= layers <= 4:
        raise ValueError("teaching generator supports 2..10 qubits and 1..4 layers")
    rng = np.random.default_rng(seed)
    circuit = QuantumCircuit(n_qubits, name=f"{family}_{n_qubits}_{seed}")
    metadata: dict[str, Any] = {"layers": layers, "generator_version": 1}
    if family == "qaoa":
        edges = [(a, a + 1) for a in range(n_qubits - 1)]
        circuit.h(range(n_qubits))
        gammas = rng.uniform(0.15, 0.85, layers)
        betas = rng.uniform(0.1, 0.6, layers)
        for gamma, beta in zip(gammas, betas):
            for a, b in edges:
                circuit.rzz(-float(gamma), a, b)
            for a in range(n_qubits):
                circuit.rx(2 * float(beta), a)
        # Mean ZZ energy determines normalized MaxCut fraction (1 - E) / 2.
        observable = SparsePauliOp.from_list([
            (pauli_label(n_qubits, {a: "Z", b: "Z"}), 1 / len(edges)) for a, b in edges])
        metadata.update(edges=edges, gammas=gammas.tolist(), betas=betas.tolist(),
                        target="mean edge ZZ; MaxCut fraction = (1 - expectation) / 2")
    elif family == "spin":
        theta = float(rng.uniform(0.1, 0.45))
        circuit.h(range(n_qubits))
        for _ in range(layers):
            for a in range(n_qubits - 1):
                circuit.rzz(2 * theta, a, a + 1)
            for a in range(n_qubits):
                circuit.rx(1.2 * theta, a)
        observable = SparsePauliOp.from_list([
            (pauli_label(n_qubits, {a: "X"}), 1 / n_qubits) for a in range(n_qubits)])
        metadata.update(time_step=theta, target="mean transverse magnetization X")
    elif family == "variational":
        for _ in range(layers):
            for a in range(n_qubits):
                circuit.ry(float(rng.uniform(-1.1, 1.1)), a)
            for a in range(n_qubits - 1):
                circuit.cx(a, a + 1)
        terms = [(pauli_label(n_qubits, {a: "Z", a + 1: "Z"}), 1.0)
                 for a in range(n_qubits - 1)]
        terms += [(pauli_label(n_qubits, {a: "X"}), 0.5) for a in range(n_qubits)]
        scale = sum(abs(c) for _, c in terms)
        observable = SparsePauliOp.from_list([(p, c / scale) for p, c in terms])
        metadata.update(target="normalized Ising energy at fixed trial parameters")
    else:
        for a in range(n_qubits):
            circuit.ry(float(rng.uniform(0.2, 1.1)), a)
        if family == "modular":
            for _ in range(layers):
                for a in range(0, n_qubits - 1, 2):
                    circuit.cx(a, a + 1)
                for a in range(1, n_qubits - 1, 2):
                    circuit.cry(float(rng.uniform(0.2, 0.7)), a, a + 1)
                for a in range(n_qubits):
                    circuit.rx(float(rng.uniform(0.1, 0.4)), a)
        observable = SparsePauliOp.from_list([
            (pauli_label(n_qubits, {0: "Z", n_qubits - 1: "Z"}), 1.0)])
        metadata.update(target="end-to-end ZZ correlation")
    hardware = PROFILES[noise]
    if topology:
        hardware = HardwareProfile(hardware.name, topology, hardware.one_qubit_error,
                                   hardware.two_qubit_error, hardware.readout_error)
    return Instance(f"{family}-n{n_qubits}-l{layers}-s{seed}-{noise}-{hardware.topology}-w{max_width}",
                    circuit, observable, max_width, shots, hardware, seed, family, metadata)


def _graph_edges(n: int, kind: str, rng, module_size: int) -> list[tuple[int, int]]:
    if kind == "path":
        edges = [(i, i + 1) for i in range(n - 1)]
    elif kind == "ring":
        edges = [(i, i + 1) for i in range(n - 1)] + [(0, n - 1)]
    elif kind == "star":
        hub = int(rng.integers(n))
        edges = [(hub, i) for i in range(n) if i != hub]
    elif kind == "tree":
        order = rng.permutation(n).tolist()
        edges = [(order[i], order[int(rng.integers(i))]) for i in range(1, n)]
    elif kind == "matching":
        order = rng.permutation(n).tolist()
        edges = [(order[i], order[i + 1]) for i in range(0, n - 1, 2)]
    elif kind == "modular":
        modules = [list(range(start, min(n, start + module_size)))
                   for start in range(0, n, module_size)]
        edges = []
        for module in modules:
            order = rng.permutation(module).tolist()
            edges += [(order[i], order[int(rng.integers(i))]) for i in range(1, len(order))]
        edges += [(int(rng.choice(left)), int(rng.choice(right)))
                  for left, right in zip(modules, modules[1:])]
    else:
        raise ValueError("graph must be path, ring, star, tree, matching, or modular")
    return sorted({tuple(sorted(edge)) for edge in edges})


def _normalize(terms: list[tuple[str, float]]) -> tuple[SparsePauliOp, dict]:
    observable = SparsePauliOp.from_list(terms).simplify()
    scale = float(np.abs(observable.coeffs).sum())
    if not scale > 0 or not math.isfinite(scale):
        raise ValueError("generated observable must have finite nonzero L1 norm")
    observable = observable / scale
    return observable, {"rule": "divide_by_coefficient_l1", "scale": scale,
                        "coefficient_l1": float(np.abs(observable.coeffs).sum()),
                        "ideal_spectral_radius_upper_bound": 1.0}


def _permutation(n: int, relabel, rng) -> list[int]:
    if relabel is None or relabel is False:
        return list(range(n))
    if relabel is True:
        return rng.permutation(n).tolist()
    try:
        labels = [_integer(value, "relabel index", 0, n-1) for value in relabel]
    except TypeError as error:
        raise ValueError("relabel must be a boolean or a full qubit permutation") from error
    if sorted(labels) != list(range(n)):
        raise ValueError("relabel must contain every qubit index exactly once")
    return labels


def make_instance(family: str = "modular", *, n_qubits: int = 4, seed: int = 17,
                  max_width: int = 2, shots: int = 12000, noise: str = "ideal",
                  layers: int = 1, topology: str | None = None,
                  generator_version: int | None = None, graph: str | None = None,
                  weighted: bool | None = None, relabel: bool | list[int] | None = None,
                  module_size: int | None = None, coupling_strength: float | None = None,
                  disorder: float | None = None, product_state: str | None = None,
                  hardware: HardwareProfile | dict | None = None) -> Instance:
    """Build a reproducible workload and normalized primary observable.

    With no v2-only keywords this preserves the original v1 circuit and ID.
    Use generator_version=2 for richer default graphs, weights, disorder, and
    relabeling. Supplying any v2-only option also selects v2 unless version=1
    is explicitly requested, in which case mixed-version options are rejected.

    Relabeling maps original logical index q to physical circuit index
    permutation[q]. It permutes the observable consistently and adds no SWAPs.
    These circuit indices are still virtual inputs to hardware transpilation.
    """
    n_qubits = _integer(n_qubits, "n_qubits", 2, 10)
    layers = _integer(layers, "layers", 1, 4)
    seed = _integer(seed, "seed", 0)
    max_width = _integer(max_width, "max_width", 1, 10)
    shots = _integer(shots, "shots", 2)
    extras = [graph, weighted, relabel, module_size, coupling_strength, disorder, product_state, hardware]
    if generator_version is None:
        generator_version = 2 if any(option is not None for option in extras) else 1
    generator_version = _integer(generator_version, "generator_version", 1, 2)
    if generator_version == 1:
        if any(option is not None for option in extras):
            raise ValueError("v2 generator options require generator_version=2")
        return _make_instance_v1(family, n_qubits=n_qubits, seed=seed, max_width=max_width,
                                 shots=shots, noise=noise, layers=layers, topology=topology)
    if family not in {"qaoa", "spin", "variational", "modular", "product"}:
        raise ValueError("unknown workload family")
    module_size = _integer(module_size if module_size is not None else max(2, n_qubits // 2),
                           "module_size", 1, n_qubits)
    coupling_strength = _finite(1.0 if coupling_strength is None else coupling_strength,
                                "coupling_strength", 0.01, 2.0)
    disorder = _finite(0.35 if disorder is None else disorder, "disorder", 0.0, 0.9)
    if weighted is not None and not isinstance(weighted, bool):
        raise ValueError("weighted must be a boolean")
    weighted = True if weighted is None else weighted
    graph = graph or ("modular" if family == "modular" else "tree")
    product_state = product_state or "random"
    if product_state not in {"random", "zero", "one", "alternating"}:
        raise ValueError("product_state must be random, zero, one, or alternating")
    if family != "product" and product_state != "random":
        raise ValueError("product_state options apply only to the product family")
    sequences = np.random.SeedSequence(seed).spawn(4)
    graph_rng, angle_rng, weight_rng, label_rng = [np.random.default_rng(sequence) for sequence in sequences]
    edges = _graph_edges(n_qubits, graph, graph_rng, module_size)
    weights = weight_rng.uniform(0.5, 1.5, len(edges)) if weighted else np.ones(len(edges))
    weights *= coupling_strength
    permutation = _permutation(n_qubits, True if relabel is None else relabel, label_rng)
    qc = QuantumCircuit(n_qubits, name=f"{family}_v2_{n_qubits}_{seed}")
    metadata: dict[str, Any] = {
        "generator_version": 2, "layers": layers, "graph": graph,
        "logical_edges": [list(edge) for edge in edges],
        "edges": [[permutation[a], permutation[b]] for a, b in edges],
        "edge_weights": weights.tolist(), "logical_to_circuit": permutation,
        "module_size": module_size, "disorder": disorder,
        "coupling_strength": coupling_strength, "weighted": weighted,
        "normalization": {}, "parameter_seed": seed,
    }
    if family == "qaoa":
        gammas = angle_rng.uniform(0.12, 0.8, layers)
        betas = angle_rng.uniform(0.08, 0.6, layers)
        qc.h(range(n_qubits))
        for gamma, beta in zip(gammas, betas):
            for (a, b), weight in zip(edges, weights):
                qc.rzz(-float(gamma * weight), a, b)
            for qubit in range(n_qubits):
                qc.rx(2 * float(beta), qubit)
        terms = [(pauli_label(n_qubits, {a: "Z", b: "Z"}), float(weight))
                 for (a, b), weight in zip(edges, weights)]
        metadata.update(gammas=gammas.tolist(), betas=betas.tolist(),
                        target="weighted mean edge ZZ",
                        objective="normalized weighted MaxCut = (1 - expectation) / 2",
                        qaoa_phase_convention="exp(-i gamma sum w*(I-ZZ)/2); RX(2 beta) mixer")
    elif family in {"spin", "variational"}:
        signs = np.where(weight_rng.random(len(edges)) < 0.25, -1.0, 1.0) if disorder else np.ones(len(edges))
        couplings = weights * signs
        fields_x = 0.65 + weight_rng.uniform(-disorder, disorder, n_qubits)
        fields_z = weight_rng.uniform(-disorder, disorder, n_qubits)
        hamiltonian_terms = [(pauli_label(n_qubits, {a: "Z", b: "Z"}), float(value))
                             for (a, b), value in zip(edges, couplings)]
        hamiltonian_terms += [(pauli_label(n_qubits, {q: "X"}), float(fields_x[q])) for q in range(n_qubits)]
        hamiltonian_terms += [(pauli_label(n_qubits, {q: "Z"}), float(fields_z[q])) for q in range(n_qubits)]
        metadata.update(couplings_zz=couplings.tolist(), fields_x=fields_x.tolist(),
                        fields_z=fields_z.tolist(), hamiltonian_logical=hamiltonian_terms)
        if family == "spin":
            dt = float(angle_rng.uniform(0.1, 0.3))
            qc.h(range(n_qubits))
            for _ in range(layers):
                for (a, b), coupling in zip(edges, couplings):
                    qc.rzz(2 * dt * float(coupling), a, b)
                for q in range(n_qubits):
                    qc.rz(2 * dt * float(fields_z[q]), q)
                for q in range(n_qubits):
                    qc.rx(2 * dt * float(fields_x[q]), q)
            terms = [(pauli_label(n_qubits, {q: "X"}), 1.0) for q in range(n_qubits)]
            metadata.update(time_step=dt, total_time=layers * dt,
                            target="mean transverse magnetization X",
                            evolution="first-order product formula: U_step=exp(-i dt H_X) exp(-i dt H_Z); fixed disorder")
        else:
            parameters = angle_rng.uniform(-1.2, 1.2, (layers, n_qubits, 2))
            for layer in parameters:
                for q, (theta, phi) in enumerate(layer):
                    qc.ry(float(theta), q)
                    qc.rz(float(phi), q)
                for a, b in edges:
                    qc.cx(a, b)
            terms = hamiltonian_terms
            metadata.update(ansatz_parameters=parameters.tolist(),
                            target="normalized disordered Ising energy at fixed trial parameters",
                            optimizer_included=False)
    elif family == "modular":
        parameters = angle_rng.uniform(0.15, 1.0, (layers, n_qubits, 2))
        controls = []
        for layer_index, layer in enumerate(parameters):
            for q, (theta, phi) in enumerate(layer):
                qc.ry(float(theta), q)
                qc.rz(float(phi), q)
            for edge_index, (a, b) in enumerate(edges):
                if a // module_size == b // module_size:
                    qc.cx(a, b)
                else:
                    control, target = (a, b) if angle_rng.random() < 0.5 else (b, a)
                    angle = float(angle_rng.uniform(0.15, 0.55) * weights[edge_index])
                    axis = "y" if angle_rng.random() < 0.5 else "z"
                    if axis == "y":
                        qc.cry(angle, control, target)
                    else:
                        qc.crz(angle, control, target)
                    controls.append(dict(layer=layer_index, axis=axis, angle=angle,
                                         logical_control=control, logical_target=target,
                                         control=permutation[control], target=permutation[target]))
            for q in range(n_qubits):
                qc.rx(float(angle_rng.uniform(0.1, 0.4)), q)
        terms = [(pauli_label(n_qubits, {0: "Z", n_qubits - 1: "Z"}), 1.0)]
        metadata.update(controlled_gates=controls, ansatz_parameters=parameters.tolist(),
                        target="logical endpoint ZZ correlation")
    else:
        # Explicit identities keep idle qubits visible to Qiskit's partitioner.
        for q in range(n_qubits):
            qc.id(q)
        angles = angle_rng.uniform(0.15, 1.1, n_qubits)
        if product_state == "random":
            for q, angle in enumerate(angles):
                qc.ry(float(angle), q)
            known_value = float(np.mean(np.cos(angles)))
        else:
            ones = [q for q in range(n_qubits) if product_state == "one" or (product_state == "alternating" and q % 2)]
            for q in ones:
                qc.x(q)
            known_value = 1 - 2 * len(ones) / n_qubits
        terms = [(pauli_label(n_qubits, {q: "Z"}), 1.0) for q in range(n_qubits)]
        metadata.update(target="mean Z", product_state=product_state,
                        analytic_reference=known_value,
                        control_note="No entangling interactions; cutting cannot improve zero ideal sampling error for basis-state controls.")
        # The graph is not applied by the uncoupled control.
        metadata.update(logical_edges=[], edges=[], edge_weights=[])
    logical_observable, normalization = _normalize(terms)
    observable = SparsePauliOp.from_list([
        (pauli_label(n_qubits, {permutation[q]: label[n_qubits - 1 - q]
                               for q in range(n_qubits) if label[n_qubits - 1 - q] != "I"}), float(coeff.real))
        for label, coeff in logical_observable.to_list()])
    circuit = QuantumCircuit(n_qubits, name=qc.name)
    circuit.compose(qc, qubits=permutation, inplace=True)
    metadata["normalization"] = normalization
    if hardware is not None:
        profile = HardwareProfile(**hardware) if isinstance(hardware, dict) else hardware
        if not isinstance(profile, HardwareProfile):
            raise ValueError("hardware must be a HardwareProfile or its keyword dictionary")
    else:
        if noise not in PROFILES:
            raise ValueError("unknown noise profile")
        profile = PROFILES[noise]
    if topology:
        profile = HardwareProfile(profile.name, topology, profile.one_qubit_error,
                                  profile.two_qubit_error, profile.readout_error)
    canonical = dict(family=family, n_qubits=n_qubits, seed=seed, max_width=max_width,
                     shots=shots, hardware=asdict(profile), metadata=metadata,
                     circuit=[dict(name=i.operation.name,
                                   qubits=[circuit.find_bit(q).index for q in i.qubits],
                                   params=[float(p) for p in i.operation.params]) for i in circuit.data],
                     observable=[(p, float(c.real)) for p, c in observable.to_list()])
    fingerprint = hashlib.sha256(json.dumps(canonical, sort_keys=True, separators=(",", ":"),
                                            allow_nan=False).encode()).hexdigest()[:16]
    metadata["fingerprint"] = fingerprint
    return Instance(f"{family}-v2-n{n_qubits}-l{layers}-s{seed}-{fingerprint}", circuit,
                    observable, max_width, shots, profile, seed, family, metadata)
