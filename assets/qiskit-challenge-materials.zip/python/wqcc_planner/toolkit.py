"""Organizer tools for procedural instances, baselines, scoring, and plan traces."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import secrets
from .benchmark import case_from_spec, save_suite, load_suite, calibrate_suite, evaluate_suite, write_json
from .bundle import plan_bundle
from .scoring import write_report


def generate(args):
    from .suites import suite_specs
    root = Path(__file__).resolve().parents[2]
    output = Path(args.output).resolve()
    if args.split == "private" and output.is_relative_to(root):
        raise ValueError("organizer-private suites must be outside the distributable toolkit directory")
    seed = args.master_seed if args.master_seed is not None else (secrets.randbits(63) if args.split == "private" else 20260920)
    specs = suite_specs(args.split, seed, preset=args.preset)
    cases = [case_from_spec(spec, args.shots) for spec in specs]
    manifest = save_suite(cases, output, provenance=dict(split=args.split, preset=args.preset,
        master_seed=seed, source="suite_specs v2", private_seed_warning="Never distribute private seeds or files."))
    print(f"Created {len(cases)} {args.split} cases: {manifest}")


def calibrate(args):
    cases = load_suite(Path(args.manifest), shots=args.shots)
    if any(case.split == "private" for case in cases) and Path(args.output).resolve().is_relative_to(Path(__file__).resolve().parents[2]):
        raise ValueError("private calibration results must stay outside the distributable toolkit")
    record = calibrate_suite(cases)
    write_json(Path(args.output), record)
    if not record["required_pass"]:
        raise SystemExit("At least one required case failed baseline feasibility calibration; inspect the report.")


def evaluate(args):
    source = Path(args.manifest)
    cases = load_suite(source, shots=args.shots)
    if any(case.split == "private" for case in cases) and Path(args.output).resolve().is_relative_to(Path(__file__).resolve().parents[2]):
        raise ValueError("private evaluation results must stay outside the distributable toolkit")
    document = evaluate_suite(cases, modes=args.modes.split(","), allocations=args.allocations.split(","),
        replicates=args.replicates, seed=args.sampling_seed, output=Path(args.output), export_plans=args.export_plans)
    write_report(document, Path(args.output))
    print(f"Saved {len(document['rows'])} complete-case run records and offline report in {args.output}")


def score(args):
    source = Path(args.input)
    document = json.loads(source.read_text(encoding="utf-8"))
    output = Path(args.output) if args.output else source.parent
    if any(c["split"] == "private" for c in document["cases"]) and output.resolve().is_relative_to(Path(__file__).resolve().parents[2]):
        raise ValueError("keep private scoring results outside the distributable toolkit")
    summary = write_report(document, output)
    print(f"Scored {len(summary['methods'])} methods; inspect {output / 'report.html'}")


def visualize(args):
    from .visualization import write_plan_artifacts
    cases = load_suite(Path(args.manifest))
    if args.case < 0 or args.case >= len(cases):
        raise ValueError("case index is outside the manifest")
    case = cases[args.case]
    if case.split == "private" and Path(args.output).resolve().is_relative_to(Path(__file__).resolve().parents[2]):
        raise ValueError("private visualizations must stay outside the distributable toolkit")
    prepared = plan_bundle(case.instance, args.mode, args.allocation)
    print(write_plan_artifacts(case.instance, prepared, Path(args.output), stem="execution-plan"))


def validate(args):
    cases = load_suite(Path(args.manifest))
    print(f"Validated {len(cases)} cases: QPY hashes, dimensions, targets, coefficients, budgets, and paths.")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("generate-suite")
    p.add_argument("--split", choices=["public", "validation", "private"], default="public")
    p.add_argument("--preset", choices=["smoke", "standard"], default="smoke")
    p.add_argument("--master-seed", type=int)
    p.add_argument("--shots", type=int, default=24000)
    p.add_argument("--output", required=True)
    p.set_defaults(func=generate)
    p = sub.add_parser("calibrate")
    p.add_argument("--manifest", required=True)
    p.add_argument("--shots", type=int)
    p.add_argument("--output", required=True)
    p.set_defaults(func=calibrate)
    p = sub.add_parser("evaluate")
    p.add_argument("--manifest", required=True)
    p.add_argument("--modes", default="direct,auto_cut,participant")
    p.add_argument("--allocations", default="coefficient")
    p.add_argument("--replicates", type=int, default=3)
    p.add_argument("--sampling-seed", type=int, default=20260920)
    p.add_argument("--shots", type=int)
    p.add_argument("--export-plans", action="store_true")
    p.add_argument("--output", required=True)
    p.set_defaults(func=evaluate)
    p = sub.add_parser("score")
    p.add_argument("--input", required=True)
    p.add_argument("--output")
    p.set_defaults(func=score)
    p = sub.add_parser("visualize")
    p.add_argument("--manifest", required=True)
    p.add_argument("--case", type=int, default=0)
    p.add_argument("--mode", default="auto_cut", choices=["direct", "auto_cut", "structured_cut", "policy", "participant"])
    p.add_argument("--allocation", choices=["equal", "coefficient"], default="coefficient")
    p.add_argument("--output", required=True)
    p.set_defaults(func=visualize)
    p = sub.add_parser("validate")
    p.add_argument("--manifest", required=True)
    p.set_defaults(func=validate)
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
