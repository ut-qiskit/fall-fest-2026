"""Observable-error scoring; incomplete methods cannot win by skipping cases."""
from __future__ import annotations
from collections import defaultdict
from pathlib import Path
import html
import json
import math
import statistics

from .benchmark import write_json


def _integer(value, name, minimum=0):
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def _finite(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} must be finite numeric data")
    return value


def summarize(document: dict) -> dict:
    if document.get("schema") != "wqcc-evaluation-v2":
        raise ValueError("not a v2 evaluation file")
    cases = {c["case_id"]: c for c in document["cases"]}
    if len(cases) != len(document["cases"]) or not cases:
        raise ValueError("case descriptions must be unique and nonempty")
    for key in ("modes", "allocations"):
        values = document[key]
        if (not isinstance(values, list) or not values or
                any(not isinstance(v, str) or not v for v in values) or len(set(values)) != len(values)):
            raise ValueError(f"{key} must be a nonempty list of distinct names")
    repetitions = _integer(document["replicates"], "repetitions", 1)
    for case in cases.values():
        _integer(case["shot_budget"], "case budget", 2)
        _integer(case["max_width"], "case width", 1)
        if not isinstance(case["required"], bool):
            raise ValueError("case required flag must be Boolean")
        if not case["target_names"] or len(set(case["target_names"])) != len(case["target_names"]):
            raise ValueError("case target names must be nonempty and unique")
    rows, keys, references = {}, set(), {}
    for row in document["rows"]:
        _integer(row["replicate"], "replicate index")
        key = (row["case_id"], row["mode"], row["allocation"], row["replicate"])
        if key in keys:
            raise ValueError("duplicate evaluation row")
        if (key[0] not in cases or key[1] not in document["modes"] or
                key[2] not in document["allocations"] or key[3] not in range(repetitions)):
            raise ValueError("evaluation row outside the declared design")
        keys.add(key)
        rows[key] = row
    methods = []
    for mode in document["modes"]:
        for allocation in document["allocations"]:
            metrics, missing = [], []
            for case in cases.values():
                observed = [rows.get((case["case_id"], mode, allocation, rep)) for rep in range(repetitions)]
                successful, reasons = [], []
                for row in observed:
                    if row is None or row.get("status") != "ok":
                        reasons.append("missing" if row is None else row.get("status", "missing-status"))
                        continue
                    targets = row.get("targets", {})
                    if set(targets) != set(case["target_names"]):
                        raise ValueError("successful row has missing/extra targets")
                    errors = []
                    total = 0
                    confidence = _finite(row["confidence"], "joint confidence")
                    if not 0 < confidence < 1:
                        raise ValueError("joint confidence must be in (0,1)")
                    target_confidence = 1 - (1-confidence) / len(targets)
                    if not 0 < target_confidence < 1:
                        raise ValueError("target confidence is not numerically representable inside (0,1)")
                    if abs(_finite(row["target_confidence"], "target confidence") - target_confidence) > 1e-12:
                        raise ValueError("target confidence does not match simultaneous interval convention")
                    for name, target in targets.items():
                        estimate = _finite(target["estimate"], "estimate")
                        truth = _finite(target["ideal_reference"], "reference")
                        refkey = (case["case_id"], name)
                        if refkey in references and abs(references[refkey] - truth) > 1e-12:
                            raise ValueError("inconsistent reference across methods/repetitions")
                        references[refkey] = truth
                        lo, hi = target["sampling_interval"]
                        _finite(lo, "interval lower bound")
                        _finite(hi, "interval upper bound")
                        if not lo <= estimate <= hi:
                            raise ValueError("sampling interval must contain the reconstructed estimate")
                        if _finite(target["sampling_standard_error_approx"], "standard error") < 0:
                            raise ValueError("standard error must be nonnegative")
                        if target["qiskit_reconstruction_agrees"] is not True:
                            raise ValueError("Qiskit reconstruction cross-check failed")
                        if abs(_finite(target["confidence"], "per-target confidence") - target_confidence) > 1e-12:
                            raise ValueError("inconsistent per-target confidence")
                        n = target["physical_shots"]
                        if isinstance(n, bool) or not isinstance(n, int) or n < 0:
                            raise ValueError("invalid target physical-shot count")
                        total += n
                        try:
                            squared = (estimate - truth) ** 2
                        except OverflowError as exc:
                            raise ValueError("nonfinite squared error") from exc
                        errors.append(_finite(squared, "squared error"))
                    _integer(row["physical_shots"], "total shots")
                    _integer(row["plan"]["maximum_experiment_width"], "executed width")
                    if total != row["physical_shots"] or total > case["shot_budget"]:
                        raise ValueError("successful row violates shared shot accounting")
                    if "shot_budget" in row and row["shot_budget"] != case["shot_budget"]:
                        raise ValueError("successful row changes the assigned budget")
                    if "physical_shots" in row["plan"] and row["plan"]["physical_shots"] != total:
                        raise ValueError("planned and executed shots disagree")
                    if row["plan"]["maximum_experiment_width"] > case["max_width"]:
                        raise ValueError("successful row violates width")
                    successful.append(statistics.mean(errors))
                complete = len(successful) == repetitions
                if case["required"] and not complete:
                    missing.append(case["case_id"])
                metrics.append(dict(case_id=case["case_id"], family=case["family"],
                    stratum=case["stratum"], split=case["split"], required=case["required"],
                    complete=complete, successful_repetitions=len(successful),
                    expected_repetitions=repetitions, failures=reasons,
                    mse=statistics.mean(successful) if complete else None,
                    rmse=math.sqrt(statistics.mean(successful)) if complete else None))
            strata = defaultdict(list)
            for metric in metrics:
                if metric["required"] and metric["complete"]:
                    strata[f"{metric['family']} / {metric['stratum']}"] .append(metric["mse"])
            strata_mse = {name: statistics.mean(values) for name, values in strata.items()}
            required_count = sum(c["required"] for c in cases.values())
            eligible = bool(required_count) and not missing
            conditional = math.sqrt(statistics.mean(strata_mse.values())) if strata_mse else None
            methods.append(dict(mode=mode, allocation=allocation, eligible=eligible,
                required_cases=required_count, complete_required_cases=required_count - len(missing),
                required_coverage=(required_count-len(missing))/required_count if required_count else None,
                missing_required_cases=missing,
                macro_rmse=conditional if eligible else None,
                conditional_completed_case_rmse=conditional,
                strata_mse=strata_mse, cases=metrics))
    return dict(schema="wqcc-score-v2", proposed_rules=True,
        formula="Mean squared error across targets, then repetitions, then cases within family/feasibility strata; equal mean over required strata; square root.",
        validity_rule="Every required case must have all repetitions and targets. Otherwise macro_rmse is null; conditional errors are not a qualifying score.",
        caution="Local simulator comparison using proposed evaluation rules. Final competition scoring requires organizer confirmation.",
        methods=methods)


def write_report(document: dict, output: Path) -> dict:
    """Save auditable scores, a text summary, and an offline HTML comparison report."""
    output.mkdir(parents=True, exist_ok=True)
    summary = summarize(document)
    write_json(output / "scores.json", summary)
    esc = html.escape
    def number(value):
        return "Unavailable" if value is None else f"{value:.6f}"
    rows = []
    markdown = ["# Planner comparison", "", "Local simulation. Lower error is better.", "",
        "| Method | Allocation | Required cases complete | Qualifying macro RMSE |",
        "| --- | --- | ---: | ---: |"]
    for method in summary["methods"]:
        coverage = f"{method['complete_required_cases']}/{method['required_cases']}"
        markdown.append(f"| {method['mode']} | {method['allocation']} | {coverage} | {number(method['macro_rmse'])} |")
        rows.append(f"<tr><td>{esc(method['mode'])}</td><td>{esc(method['allocation'])}</td>"
                    f"<td>{coverage}</td><td>{number(method['macro_rmse'])}</td>"
                    f"<td>{number(method['conditional_completed_case_rmse'])}</td></tr>")
    markdown += ["", summary["formula"], "", summary["validity_rule"], "",
                 "Conditional error in scores.json uses completed required cases only and is not comparable across different coverage.", ""]
    (output / "summary.md").write_text("\n".join(markdown), encoding="utf-8")
    details = []
    for method in summary["methods"]:
        entries = []
        for case in method["cases"]:
            status = number(case["rmse"]) if case["complete"] else ", ".join(sorted(set(case["failures"])))
            entries.append(f"<tr><td>{esc(case['case_id'])}</td><td>{esc(case['family'])}</td>"
                f"<td>{esc(case['stratum'])}</td><td>{case['successful_repetitions']}/{case['expected_repetitions']}</td><td>{esc(status)}</td></tr>")
        details.append(f"<details><summary>{esc(method['mode'])} / {esc(method['allocation'])}: individual cases</summary>"
            "<table><thead><tr><th>Case</th><th>Family</th><th>Stratum</th><th>Repeats</th><th>RMSE or status</th></tr></thead><tbody>"
            + "".join(entries) + "</tbody></table></details>")
    page = """<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>WQCC planner comparison</title><style>
body{font:17px/1.55 system-ui,sans-serif;color:#20242a;background:#f6f7fb;margin:0}main{max-width:1180px;margin:3rem auto;padding:0 2rem}
h1{font-size:2.6rem;font-weight:550;letter-spacing:-.04em;margin-bottom:.4rem}h2{font-size:1.3rem}.eyebrow{color:#6335a5;font-weight:650}
section,details{background:white;border:1px solid #dfe2ec;border-radius:10px;padding:1.3rem;margin:1.4rem 0;overflow:auto}
table{border-collapse:collapse;width:100%;font-size:.91rem}td,th{padding:.75rem;border-bottom:1px solid #e8eaf2;text-align:left}th{background:#f1edf8}
summary{cursor:pointer;font-weight:600}.note{color:#555e70}a{color:#6335a5}code{background:#f0edf7;padding:.1rem .3rem}
</style><main><p class="eyebrow">WQCC · EXECUTION PLANNER TOOLKIT</p><h1>Observable accuracy under one shared budget</h1>
<p>Each repetition receives its own full budget. All target observables share that allowance. Results are synthetic local simulations.</p>
<section><h2>Required-case comparison</h2><table><thead><tr><th>Method</th><th>Allocation</th><th>Complete required cases</th><th>Qualifying macro RMSE</th><th>Conditional error</th></tr></thead><tbody>"""
    page += "".join(rows) + "</tbody></table><p class='note'>Conditional error uses completed cases only. It cannot rank methods with different coverage. Direct execution is unavailable when width is insufficient.</p></section>"
    stratum_names = sorted({s for m in summary["methods"] for s in m["strata_mse"]})
    page += "<section><h2>Compare like-for-like strata</h2><p>Each cell is RMSE on the completed required cases in that stratum. Check per-case completeness below; unavailable cells are not zero error.</p><table><thead><tr><th>Stratum</th>"
    page += "".join(f"<th>{esc(m['mode'])} / {esc(m['allocation'])}</th>" for m in summary["methods"])
    page += "</tr></thead><tbody>"
    for stratum in stratum_names:
        page += f"<tr><td>{esc(stratum)}</td>" + "".join(
            "<td>" + number(math.sqrt(m["strata_mse"][stratum]) if stratum in m["strata_mse"] else None) + "</td>"
            for m in summary["methods"]) + "</tr>"
    page += "</tbody></table></section>"
    page += f"<section><h2>How the score is calculated</h2><p>{esc(summary['formula'])}</p><p>{esc(summary['validity_rule'])}</p>"
    page += "<p>These evaluation rules are proposed. Final competition scoring requires organizer confirmation. Technical insight and reproducibility require assessment of the submitted work.</p>"
    links = [("scores.json", "Scoring details"), ("evaluation.csv", "Per-target measurements"), ("evaluation.json", "Complete run records")]
    page += "<p>" + " · ".join(f"<a href='{f}'>{label}</a>" for f, label in links if (output/f).exists()) + "</p></section>"
    page += "".join(details) + "</main></html>"
    (output / "report.html").write_text(page, encoding="utf-8")
    return summary
