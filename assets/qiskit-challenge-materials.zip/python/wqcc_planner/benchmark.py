"""Versioned benchmark files and honest, repeated multi-observable evaluation."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import csv
import hashlib
import json
import math
import platform
import importlib.metadata
import numpy as np
from qiskit import qpy
from qiskit.quantum_info import SparsePauliOp, Statevector

from .instances import Instance, HardwareProfile, make_instance, pauli_label
from .engine import InfeasiblePlan, Limits
from .bundle import MultiObservableInstance, plan_bundle, execute_bundle


SCHEMA = "wqcc-benchmark-v2"


def write_json(path: Path, value: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    def default(x):
        if isinstance(x, np.generic):
            return x.item()
        if isinstance(x, np.ndarray):
            return x.tolist()
        raise TypeError(type(x).__name__)
    path.write_text(json.dumps(value, indent=2, default=default, allow_nan=False) + "\n", encoding="utf-8")


def environment():
    return {"python": platform.python_version(), "platform": platform.platform(),
            "packages": {p: importlib.metadata.version(p) for p in
                         ("qiskit", "qiskit-aer", "qiskit-addon-cutting", "numpy", "scipy")}}


def file_hash(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


@dataclass
class BenchmarkCase:
    case_id: str
    instance: MultiObservableInstance
    split: str
    stratum: str
    required: bool = True


def case_from_spec(spec: dict, shots: int = 24000) -> BenchmarkCase:
    kwargs = dict(spec["kwargs"])
    if isinstance(kwargs.get("hardware"), dict):
        kwargs["hardware"] = HardwareProfile(**kwargs["hardware"])
    kwargs["shots"] = shots
    base = make_instance(**kwargs)
    n = base.circuit.num_qubits
    targets = {"primary": base.observable,
               "magnetization_z": SparsePauliOp.from_list([
                   (pauli_label(n, {q: "Z"}), 1 / n) for q in range(n)])}
    return BenchmarkCase(spec["case_id"], MultiObservableInstance(base, targets),
                         spec["split"], spec["stratum"], spec.get("required", True))


def save_suite(cases: list[BenchmarkCase], output: Path, *, provenance: dict) -> Path:
    """Create a new directory; never silently replace a released/private suite."""
    if not cases:
        raise ValueError("suite must contain at least one case")
    if len({c.case_id for c in cases}) != len(cases):
        raise ValueError("case IDs must be unique")
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"suite output is not empty: {output}")
    output.mkdir(parents=True, exist_ok=True)
    records = []
    for index, case in enumerate(cases):
        filename = f"circuit-{index:03d}.qpy"
        with (output / filename).open("wb") as stream:
            qpy.dump(case.instance.base.circuit, stream)
        records.append(dict(case_id=case.case_id, split=case.split, stratum=case.stratum,
            required=case.required, instance=case.instance.base.specification(),
            targets={name: [(label, float(weight.real)) for label, weight in op.to_list()]
                     for name, op in case.instance.targets.items()},
            circuit_file=filename, circuit_sha256=file_hash(output / filename)))
    manifest = output / "manifest.json"
    write_json(manifest, dict(schema=SCHEMA, generator_environment=environment(),
        provenance=provenance, private=any(c.split == "private" for c in cases), cases=records))
    return manifest


def load_suite(manifest: Path, *, shots: int | None = None) -> list[BenchmarkCase]:
    """Verify hashes and paths before loading the exact exported Qiskit circuits."""
    manifest = manifest.resolve()
    document = json.loads(manifest.read_text(encoding="utf-8"))
    if document.get("schema") != SCHEMA or not document.get("cases"):
        raise ValueError("unsupported or empty benchmark manifest")
    cases, ids = [], set()
    for record in document["cases"]:
        cid = record["case_id"]
        if not isinstance(cid, str) or not cid or cid in ids:
            raise ValueError("invalid or duplicate case ID")
        ids.add(cid)
        source = (manifest.parent / record["circuit_file"]).resolve()
        if not source.is_relative_to(manifest.parent):
            raise ValueError("circuit file escapes the suite directory")
        if file_hash(source) != record["circuit_sha256"]:
            raise ValueError(f"circuit hash mismatch for {cid}")
        with source.open("rb") as stream:
            circuits = qpy.load(stream)
        if len(circuits) != 1:
            raise ValueError("one circuit is required per QPY file")
        spec = record["instance"]
        base = Instance(spec["instance_id"], circuits[0], SparsePauliOp.from_list(spec["observable"]),
            spec["max_width"], shots if shots is not None else spec["shots"],
            HardwareProfile(**spec["hardware"]), spec["seed"], spec["family"], spec.get("metadata", {}))
        if circuits[0].num_qubits != spec["n_qubits"]:
            raise ValueError("manifest circuit width does not match QPY")
        targets = {name: SparsePauliOp.from_list(terms) for name, terms in record["targets"].items()}
        if record["split"] not in {"public", "validation", "private"}:
            raise ValueError("unknown benchmark split")
        if not isinstance(record["required"], bool):
            raise ValueError("required flag must be Boolean")
        cases.append(BenchmarkCase(cid, MultiObservableInstance(base, targets),
            record["split"], record["stratum"], record["required"]))
    return cases


def case_description(case: BenchmarkCase) -> dict:
    base = case.instance.base
    return dict(case_id=case.case_id, split=case.split, stratum=case.stratum,
        required=case.required, family=base.family, n_qubits=base.circuit.num_qubits,
        max_width=base.max_width, shot_budget=base.shots, hardware=base.specification()["hardware"],
        target_names=list(case.instance.targets),
        direct_feasible=base.circuit.num_qubits <= base.max_width)


def calibrate_suite(cases: list[BenchmarkCase], *, limits: Limits | None = None) -> dict:
    """Check bounded automatic-baseline feasibility. Does not cherry-pick accuracy."""
    rows = []
    for case in cases:
        row = case_description(case)
        try:
            prepared = plan_bundle(case.instance, "auto_cut", limits=limits)
            row.update(status="ok", plan=prepared.summary())
        except InfeasiblePlan as exc:
            row.update(status="infeasible", reason=str(exc))
        except Exception as exc:
            row.update(status="error", reason=f"{type(exc).__name__}: {exc}")
        rows.append(row)
        print(f"Calibration {case.case_id}: {row['status']}", flush=True)
    return dict(schema="wqcc-calibration-v2", environment=environment(),
        required_pass=all(r["status"] == "ok" for r in rows if r["required"]), cases=rows)


def evaluate_suite(cases: list[BenchmarkCase], *, modes: list[str], allocations: list[str],
                   replicates: int = 3, seed: int = 20260920,
                   output: Path, limits: Limits | None = None, export_plans: bool = False) -> dict:
    """Organizer runner: references stay outside the participant planner call.

    This is transparent local evaluation, not an adversarial sandbox. A complete
    repetition has ONE budget shared by all targets; repetitions are not pooled.
    """
    if isinstance(replicates, bool) or not isinstance(replicates, int) or replicates < 1:
        raise ValueError("replicates must be a positive integer")
    if not cases or len({case.case_id for case in cases}) != len(cases):
        raise ValueError("evaluation requires nonempty unique cases")
    if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
        raise ValueError("sampling seed must be a nonnegative integer")
    if not modes or len(set(modes)) != len(modes) or set(modes) - {"direct", "auto_cut", "structured_cut", "policy", "participant"}:
        raise ValueError("choose distinct supported modes")
    if not allocations or len(set(allocations)) != len(allocations) or set(allocations) - {"equal", "coefficient"}:
        raise ValueError("choose distinct supported allocations")
    output.mkdir(parents=True, exist_ok=True)
    if (output / "evaluation.json").exists():
        raise FileExistsError("use a fresh result directory to preserve earlier comparisons")
    document = dict(schema="wqcc-evaluation-v2", environment=environment(),
        cases=[case_description(c) for c in cases], modes=modes, allocations=allocations,
        replicates=replicates, sampling_seed=seed, rows=[],
        resource_rule="One total physical-shot allowance per case/method/repetition, shared across targets.",
        uncertainty_target="Noisy reconstructed estimand; excludes bias relative to ideal circuit.")
    for ci, case in enumerate(cases):
        state = Statevector.from_instruction(case.instance.base.circuit)
        reference = {name: float(state.expectation_value(op).real) for name, op in case.instance.targets.items()}
        for mode in modes:
            for allocation in allocations:
                common = dict(case_id=case.case_id, mode=mode, allocation=allocation)
                try:
                    prepared = plan_bundle(case.instance, mode, allocation, limits=limits)
                    if export_plans:
                        from .visualization import write_plan_artifacts
                        write_plan_artifacts(case.instance, prepared,
                            output / "plans", stem=f"case-{ci:03d}-{mode}-{allocation}")
                    planning_failure = None
                except InfeasiblePlan as exc:
                    planning_failure = ("unavailable" if mode == "direct" and not
                        case_description(case)["direct_feasible"] else "infeasible", str(exc))
                except Exception as exc:
                    planning_failure = ("error", f"{type(exc).__name__}: {exc}")
                for rep in range(replicates):
                    sampling_seed = int(np.random.SeedSequence([seed, ci, rep]).generate_state(1)[0])
                    row = dict(**common, replicate=rep, sampling_seed=sampling_seed)
                    if planning_failure:
                        row.update(status=planning_failure[0], reason=planning_failure[1])
                    else:
                        try:
                            measured = execute_bundle(case.instance, prepared, seed=sampling_seed)
                            targets = {}
                            for name, value in measured["targets"].items():
                                targets[name] = {key: value[key] for key in (
                                    "estimate", "sampling_interval", "sampling_standard_error_approx",
                                    "confidence", "physical_shots", "qiskit_reconstruction_agrees", "execution_seconds")}
                                targets[name].update(ideal_reference=reference[name],
                                    squared_error=(value["estimate"] - reference[name]) ** 2)
                            row.update(status="ok", targets=targets,
                                physical_shots=measured["physical_shots"],
                                shot_budget=measured["shot_budget"], confidence=measured["confidence"],
                                target_confidence=measured["target_confidence"],
                                execution_seconds=measured["execution_seconds"],
                                plan=prepared.summary(),
                                mse=float(np.mean([t["squared_error"] for t in targets.values()])))
                        except Exception as exc:
                            row.update(status="error", reason=f"{type(exc).__name__}: {exc}")
                    document["rows"].append(row)
                print(f"Evaluated {case.case_id}: {mode}/{allocation} [{document['rows'][-1]['status']}]", flush=True)
                write_json(output / "evaluation.json", document)
    flattened = []
    descriptions = {case["case_id"]: case for case in document["cases"]}
    for row in document["rows"]:
        base = {k: row[k] for k in ("case_id", "mode", "allocation", "replicate", "sampling_seed", "status")}
        base.update({k: descriptions[row["case_id"]][k] for k in ("family", "stratum", "split", "required", "n_qubits", "max_width")})
        base.update(reason=row.get("reason", ""), total_physical_shots=row.get("physical_shots", ""))
        if row["status"] == "ok":
            summary = row["plan"]
            base.update(planning_seconds=summary["planning_seconds"],
                total_execution_seconds=row["execution_seconds"],
                maximum_experiment_width=summary["maximum_experiment_width"],
                total_experiments=summary["experiments"],
                shot_weighted_two_qubit_gates=summary["shot_weighted_two_qubit_gates"],
                maximum_two_qubit_depth=max(t["maximum_two_qubit_depth"] for t in summary["targets"].values()),
                maximum_qpd_overhead=max(t["maximum_qpd_overhead"] for t in summary["targets"].values()))
        for name, target in row.get("targets", {"": {}}).items():
            flat = dict(**base, target=name)
            flat.update({k: v for k, v in target.items() if k != "sampling_interval"})
            if "sampling_interval" in target:
                flat.update(interval_lower=target["sampling_interval"][0], interval_upper=target["sampling_interval"][1])
            flattened.append(flat)
    fields = list(dict.fromkeys(k for row in flattened for k in row))
    with (output / "evaluation.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(flattened)
    return document
