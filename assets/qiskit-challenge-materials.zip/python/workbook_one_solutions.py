"""Workbook 1 reference solutions; no experiments run on import.

Read after attempting the exercises. comparison() uses a separate request
budget for every method/repetition and takes no ideal-answer input.
"""
from __future__ import annotations
import numpy as np


def z_scores(records, qubits):
    records = np.asarray(records, dtype=int)
    return 1 - 2 * (records[:, list(qubits)].sum(axis=1) % 2)


def crossing_indices(circuit, partition_labels):
    return [
        index for index, instruction in enumerate(circuit.data)
        if len(instruction.qubits) == 2 and len({
            partition_labels[circuit.find_bit(q).index]
            for q in instruction.qubits
        }) > 1
    ]


def rzz_coefficients(angle):
    mixed = np.sin(angle)/2
    return np.array([np.cos(angle/2)**2, np.sin(angle/2)**2,
                     mixed, -mixed, mixed, -mixed], dtype=float)


def gamma_squared(coefficients):
    return float(np.sum(np.abs(coefficients))**2)


def signed_scores(cut_bits, final_bits):
    return 1 - 2 * ((np.asarray(cut_bits, dtype=int)
                     + np.asarray(final_bits, dtype=int)) % 2)


def reconstruct(coefficients, a_means, b_means):
    contributions = (np.asarray(coefficients, dtype=float)
                     * np.asarray(a_means, dtype=float)
                     * np.asarray(b_means, dtype=float))
    return contributions, float(contributions.sum())


def equal_allocation(budget, experiment_count):
    if experiment_count <= 0 or budget < 2*experiment_count:
        raise ValueError("Need positive experiment count and two shots per experiment.")
    common, remainder = divmod(budget, experiment_count)
    return [common + (i < remainder) for i in range(experiment_count)]


UNCERTAINTY_RESPONSES = {
    "narrow_but_misses_ideal":
        "There may be little sampling variation but appreciable hardware bias "
        "relative to the ideal circuit. A reconstruction error or violated "
        "sampling assumptions is another possibility. One miss does not identify "
        "the cause; even a calibrated 95% procedure can miss its target.",
    "one_interval_contains_reference":
        "This observed interval contains this circuit's diagnostic answer. One "
        "inclusion does not establish 95% empirical coverage, low typical error, "
        "an advantage over direct execution, or generalization.",
    "more_shots":
        "For a fixed valid decomposition and stationary independent sampling, "
        "more shots reduce sampling uncertainty, though coefficient amplification "
        "remains. Hardware bias, a wrong formula, or a target mismatch may persist.",
}


def comparison(base, plans, seeds):
    """Run each method/repetition request with its own seed and retain every result."""
    import pandas as pd
    from wqcc_planner.engine import execute
    seed_values = [int(value) for value in seeds]
    if not seed_values:
        raise ValueError("At least one repetition is required.")
    children = np.random.SeedSequence(seed_values).spawn(len(plans)*len(seed_values))
    rows = []
    child_index = 0
    for method, candidate in plans.items():
        for repetition in range(len(seed_values)):
            sampler_seed = int(children[child_index].generate_state(1, dtype=np.uint32)[0])
            child_index += 1
            result = execute(base, candidate, seed=sampler_seed)
            rows.append({"method": method, "repetition": repetition,
                         "estimate": result["estimate"],
                         "physical_shots": result["physical_shots"]})
    return pd.DataFrame(rows)


WRITTEN_GUIDANCE = {
    "E1": "IZZI selects q1 and q2. Their outcome product is a correlation; "
          "the sum of the individual means is a different observable.",
    "E2": "RZZ(0.4) stays in A, RZZ(0.55) in B, RZZ(pi/6) crosses. All wires "
          "in one group leaves no crossing but needs width four.",
    "E3": "At zero, only I/I is nonzero. Negative angles reverse the four mixed "
          "signs but leave squared terms and gamma squared unchanged at equal "
          "magnitude. Four is an overhead indicator; here there are twelve settings.",
    "E4": "Negative scores are classical weights on valid records. Both cut "
          "measurement branches remain in the average.",
    "E5": "Misaligned rows combine unrelated local actions and break the identity. "
          "Independent A/B data makes the product of sample averages unbiased "
          "for the product of local expected scores.",
    "E6": "Twelve settings with 12,000 shots each spend 144,000, not 12,000. "
          "Allocation changes the distribution of a fixed total; local "
          "variances matter as well as coefficient magnitudes.",
    "E8": "Keep every repetition, the budget per request, and RMSE from all "
          "retained errors. One noiseless instance, few repeats, and one "
          "partition do not establish general superiority. Vary circuit "
          "seeds, angles, profiles, and feasibility conditions. Ideal answers "
          "are for post-run analysis, never planner decisions.",
}
