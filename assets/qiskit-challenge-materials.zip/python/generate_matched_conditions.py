"""Export matched circuit/target specimens under one changed condition axis."""
from pathlib import Path
import argparse
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from wqcc_planner.conditions import save_matched_suite, AXES


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--axis", choices=AXES, default="topology")
    parser.add_argument("--values", help="comma-separated topologies, noise multipliers, widths, or shot counts")
    parser.add_argument("--per-family", type=int, default=1)
    parser.add_argument("--families", default="qaoa,spin,variational,modular")
    args = parser.parse_args()
    values = None
    if args.values is not None:
        parts = args.values.split(",")
        try:
            values = [part.strip() for part in parts] if args.axis == "topology" else [
                (float(part) if args.axis == "noise" else int(part)) for part in parts]
        except ValueError:
            parser.error("--values must contain values appropriate to the selected axis")
    result = save_matched_suite(Path(args.manifest), Path(args.output), axis=args.axis,
                               values=values, per_family=args.per_family,
                               families=[part.strip() for part in args.families.split(",")])
    print(f"Created matched {args.axis} diagnostic suite: {result}")


if __name__ == "__main__":
    main()
