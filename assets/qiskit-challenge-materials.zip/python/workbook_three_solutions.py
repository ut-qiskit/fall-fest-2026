"""Reference answers for workbook 3. Read after attempting each exercise.

Importing this module does not run experiments or write files.
The policy is an example for evaluation; its results include feasibility failures.
"""
from wqcc_planner.engine import InfeasiblePlan


def permitted_features():
    return {"compiled_depth": True, "backend_error": True,
            "ideal_expectation": False, "hidden_test_error": False}


def proxy_arithmetic():
    sampling, noise = 4 / 2000, (0.03 * 3) ** 2
    return sampling, noise, sampling + noise


def proxy_components(instance, candidate):
    """Compute a ranking heuristic from plan features and synthetic noise rates."""
    summary = candidate.summary()
    mean_gates = summary["shot_weighted_two_qubit_gates"] / max(1, summary["physical_shots"])
    sampling = summary["maximum_qpd_overhead"] / instance.shots
    noise = (instance.hardware.two_qubit_error * mean_gates) ** 2
    return {"sampling_proxy": sampling, "noise_proxy": noise,
            "proxy_score": sampling + noise}


def my_selector(instance, candidates):
    if not candidates:
        raise InfeasiblePlan("no feasible candidate")
    return min(candidates, key=lambda candidate: (
        proxy_components(instance, candidate)["proxy_score"],
        candidate.strategy != "direct", candidate.summary()["experiments"]))


def design_prediction(cases=10, methods=4, repetitions=2, shots=12000,
                      width_constrained_cases=4):
    return {"requests": cases * methods * repetitions,
            "direct_unavailable": width_constrained_cases * repetitions,
            "shot_ceiling": (cases * methods - width_constrained_cases) * repetitions * shots}


REMOVAL_IS_VALID_RANKING = False
REMOVAL_REASON = (
    "Removing failed cases changes the evaluated population; compare complete "
    "coverage or explicitly report a common, predeclared subset without claiming "
    "that its conditional error is a qualifying full-suite score."
)


def finding_template():
    """Template for reporting the measured results of a comparison."""
    return (
        "For [case ID], starter RMSE was [measured value] and proxy RMSE was "
        "[measured value] over two 12,000-shot repetitions. Both completed "
        "[targets/requests]. The chosen plan [changed/did not change] from "
        "[strategy] to [strategy]. This small development result suggests "
        "[interpretation], with [regression/coverage/uncertainty limitation]; "
        "it does not establish performance on unseen cases."
    )


def validation_plan_example():
    return {
        "hypothesis": "The frozen proxy will reduce required-stratum macro-RMSE on fresh six-qubit cases while completing all required requests.",
        "failure_criterion": "Any missing required request, or macro-RMSE at least as large as the starter on the predeclared comparison, fails this hypothesis.",
        "frozen": "Freeze code and its hash, resource caps, shot count, repetitions, seeds, case-selection rule, and score definition before viewing validation errors.",
    }


def capstone_example():
    return {
        "interface": "Replace one candidate-allocation stage with an observable-aware fixed allocation; preserve the assigned circuit, targets, and ExecutionPlan contract.",
        "resources": "Charge every physical experiment and any pilot shots to the same shared budget; retain width/expansion caps and record classical planning time.",
        "baseline": "Compare equal and coefficient allocation plus the unmodified planner at identical budgets and complete required-case coverage.",
        "stress_cases": "Test four families, new graph draws and sizes, direct-feasible and width-constrained cases, deterministic product controls, and separately matched noise settings.",
        "falsification": "Reject a universal-improvement claim if any required request fails or a predeclared validation stratum regresses; report limited effects with the observed uncertainty.",
    }
