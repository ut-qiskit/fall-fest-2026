"""Run the score benchmark tool; see --help."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from wqcc_planner.toolkit import main

if __name__ == "__main__":
    main(["score", *sys.argv[1:]])
