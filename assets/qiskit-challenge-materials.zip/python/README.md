# Python tools for the WQCC planner challenge

Start with the [prompt guide](../planner-prompt.md) and the three notebooks.
This directory contains their supporting library, optional exercise answers,
and command-line tools for further experiments. You do not need to read every
module before starting Workbook 1.

[Setup](#install-and-open-the-notebooks) · [Script catalog](#what-is-in-this-folder) ·
[First study](#a-first-command-line-study) · [Edit your planner](#where-to-make-a-change) ·
[Leader guidance](#for-event-leaders) · [Troubleshooting](#troubleshooting) ·
[Evaluation contract](#evaluation-contract) · [Generators](#generator-details)

## Install and open the notebooks

Extract the entire ZIP. Run these commands from the extracted folder containing
`planner-prompt.md` and the three notebooks. **Python 3.12 is recommended.**

Windows PowerShell:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r python/requirements.txt
.\.venv\Scripts\python.exe python/check_environment.py
.\.venv\Scripts\python.exe -m jupyterlab
```

macOS or Linux:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r python/requirements.txt
.venv/bin/python python/check_environment.py
.venv/bin/python -m jupyterlab
```

The examples below use `python` as shorthand for **that environment's Python**:
substitute `.\.venv\Scripts\python.exe` on Windows or `.venv/bin/python` on
macOS/Linux. No environment activation or PowerShell policy change is needed.
Installation downloads dependencies. The notebooks and scripts then run local
simulation without accounts or tokens. Upstream dependencies can include IBM
Runtime even though this package makes no cloud calls.

Open Workbook 1 in JupyterLab. Select cells in order and press Shift+Enter.
Use a kernel belonging to this environment. The notebook contains its own
instructions, worked examples, hints, and response spaces. Save your edits.
Restart the kernel before a complete rerun or after changing a library module.

## What is in this folder?

| File or directory | Purpose | Who normally uses it? |
|---|---|---|
| `requirements.txt` | Pinned dependencies for notebooks and local experiments. | Everyone, once during setup. |
| `check_environment.py` | A bounded import, compilation, and 64-shot Aer check. | Everyone if checking an installation. |
| `generate_benchmarks.py` | Generate reproducible circuit suites, targets, and manifest files. | Participants for development; leaders for fresh evaluation suites. |
| `validate_suite.py` | Check circuit hashes, dimensions, target definitions, paths, and resource fields. | Both roles before evaluation. |
| `calibrate_suite.py` | Check whether the bounded automatic baseline can prepare the required requests. Records all outcomes without selecting favorable accuracy. | Mainly leaders designing suites; participants diagnosing new cases. |
| `evaluate_planners.py` | Run methods under common constraints and save successes, failures, resources, and estimates. | Both roles. |
| `score_results.py` | Summarize saved evaluations as coverage and development macro RMSE. | Both roles; this does not assign final competition points. |
| `generate_matched_conditions.py` | Vary topology, noise strength, width, or shots while preserving the exact circuits and targets. | Participants testing a hypothesis; leaders designing controlled comparisons. |
| `visualize_plan.py` | Export the actual prepared cuts, fragments, physical layouts, and shot ledger as JSON and SVG. | Both roles. This prepares a plan without sampling it. |
| `workbook_one_solutions.py`, `workbook_two_solutions.py`, `workbook_three_solutions.py` | Optional reference functions and discussion guidance. Importing them runs no experiments. | Learners after an attempt; facilitators checking answers. |
| `wqcc_planner/` | The shared implementation imported by the notebooks and tools. | Start with `participant.py`; consult other modules when changing their stage. |

Every command-line tool accepts `--help`. Input and output paths are relative
to your terminal's working directory. The examples assume the package root.
Generated `data` and `results` folders are created by your commands; they are
not missing files from the download. Keep result folders out of a clean
redistribution unless you deliberately want to share that experiment.

## A first command-line study

The notebooks already generate their own examples. These commands start a
separate development study and do not depend on running a notebook first:

```text
python python/check_environment.py
python python/generate_benchmarks.py --split public --preset smoke --master-seed 314159 --output data/my-public
python python/validate_suite.py --manifest data/my-public/manifest.json
python python/calibrate_suite.py --manifest data/my-public/manifest.json --output results/my-calibration.json
python python/evaluate_planners.py --manifest data/my-public/manifest.json --modes direct,auto_cut,participant --replicates 2 --output results/my-comparison
python python/score_results.py --input results/my-comparison/evaluation.json
python python/visualize_plan.py --manifest data/my-public/manifest.json --case 0 --mode participant --output results/my-plan
python python/generate_matched_conditions.py --manifest data/my-public/manifest.json --axis topology --output data/my-topology-study
```

Calibration may identify a case that exceeds a planning cap. Read the report;
keep that outcome visible and decide the suite's required/optional status
before making performance claims. The evaluator itself preserves failures.
Two repetitions are a short operational example, not enough to support a
broad statistical claim. Search and compilation costs depend on your machine.
Use a new output directory for a new comparison; existing evaluation evidence
is protected from accidental overwrite.

`evaluation.json` retains complete request records, including failures.
`evaluation.csv` provides successful target rows and explicit failure rows.
`scores.json` and `report.html` show coverage and accuracy. A plan SVG describes
what was prepared; a separate sampled result establishes that it ran.

## Where to make a change

The main entry for a first Builder experiment is
[`wqcc_planner/participant.py`](wqcc_planner/participant.py), especially
`select_candidate(instance, candidates)`. Workbook 3 demonstrates a temporary
replacement in the running kernel and restores the original function afterward.
To use your change in a command-line study, save it in `participant.py` and
preserve the function signature. Record the unmodified baseline before editing.

The evaluation path is: load the bound request; plan each target; combine the
plans under one global budget; validate; sample; reconstruct; then score against
independent ideal references. Plans that were feasible per target can exceed
a shared cap after combination. A target-wise choice does not automatically
produce a feasible whole request.

| Module under `wqcc_planner/` | Responsibility |
|---|---|
| `participant.py` | Candidate selection and editable planner entry point. |
| `instances.py`, `suites.py` | Circuit generators, observables, profiles, and suite specifications. |
| `engine.py` | Planning, cut finding, compilation, experiment generation, sampling, and reconstruction. |
| `bundle.py` | Multiple named observables, one physical-shot budget, and simultaneous uncertainty. |
| `statistics.py` | Integer shot allocation, product variance, and conservative intervals. |
| `benchmark.py`, `scoring.py` | Manifests, repeated evaluation, references, complete-case checks, and reporting. |
| `conditions.py` | Matched experiments with one changed condition axis. |
| `visualization.py` | Actual execution-plan JSON and SVG. |
| `toolkit.py` | The shared implementation behind the command-line wrappers. |
| `__init__.py`, `__main__.py` | Package initialization and the earlier single-target API. Use the documented wrappers for the shared-budget workflow. |

`direct` compiles the original circuit if it fits. `auto_cut` uses Qiskit's
automatic **gate**-cut search. `structured_cut` splits consecutive input-qubit
blocks and can perform poorly after relabeling. `policy` selects direct when
it fits, otherwise automatic cutting. `participant` uses the editable rule.

For independent Python scripts, add this `python` directory to your import path
or keep the script beside these wrappers. Put automatic-search execution under
`if __name__ == "__main__":`, as the wrappers do, for Windows subprocess support.

## For event leaders

Participants can use every public tool. The role distinction concerns how data
and rules are managed, rather than a secret second set of scripts.

1. Choose and announce the track-specific scope, constraints, allowed resources,
   evaluation procedure, and submission format. Numerical judging weights and
   the accuracy-to-points conversion are still proposed or undefined.
2. Use public and validation cases for instruction. Once a team has used a case
   for tuning, that case is development data for that team.
3. Generate fresh held-out cases in a directory **outside this package**, with
   a leader-held seed. The `private` split without `--master-seed` creates a
   fresh seed and records it in its private provenance. For example, from the
   package root:

   ```text
   python python/generate_benchmarks.py --split private --preset smoke --output ../leader-held-evaluation/cases
   python python/validate_suite.py --manifest ../leader-held-evaluation/cases/manifest.json
   python python/calibrate_suite.py --manifest ../leader-held-evaluation/cases/manifest.json --output ../leader-held-evaluation/calibration.json
   ```

   Keep this separate directory, including seed records, manifests, references,
   and results, out of participant distributions. These commands are examples
   for leaders; participants do not need to run them. A `private` label alone
   does not prevent access.
4. Calibrate feasibility under the announced limits and retain failure reasons.
   Do not choose a final suite based on favorable accuracy for a particular team.
5. Run frozen submissions in an organizer-controlled environment with reference
   answers separated from planner code. This trusted local runner does not
   implement adversarial isolation or enforce a global participant-code timeout.
6. Report required-case coverage, matching-case comparisons, and the raw metric
   alongside any final points. Use the same announced design for comparable
   submissions. Reserve optional stresses separately.

The eight-qubit `private` preset is a development starting point. Its name does
not make it a final or universally feasible judging suite. Generate fresh
specimens if held-out cases become known.

## Troubleshooting

- **An import fails:** verify the notebook's `sys.executable` points to the
  environment where you installed `requirements.txt`. Restart the kernel after
  installation. Keep the complete package together.
- **Compilation appears slow:** `check_environment.py` reports its import,
  compilation, and local-sampling phases and has a default 120-second timeout.
  Scientific thread startup can be limited before launching Jupyter with
  `OPENBLAS_NUM_THREADS=1`, `OMP_NUM_THREADS=1`, and `MKL_NUM_THREADS=1`.
  In PowerShell use `$env:OPENBLAS_NUM_THREADS='1'`, and similarly for the others.
- **Exercises still say Pending:** worked examples run independently of your
  answers. Fill the response slots and rerun their check cells. Numerical
  checks do not assess written explanations.
- **An edited policy appears unchanged:** save the file and restart the kernel.
  The notebook's temporary selector affects only that process; CLI runs import
  the saved `participant.py`.
- **An evaluation refuses its output directory:** choose a new directory so
  earlier results remain intact.
- **A plan is unavailable or infeasible:** read its reason. Direct width,
  QPD expansion, experiment count, and shared shot constraints are distinct.
  Preserve the result. Unexpected exceptions remain visible separately.

The sections below document the actual implemented conventions for deeper work.


## Evaluation contract

These implemented conventions define reproducible development comparisons
under a fixed resource budget. Their use for final judging remains subject
to organizer confirmation.

### One request and its resource boundary

A manifest records one bound Qiskit circuit, one to eight named real Hermitian
Pauli-sum observables, explicit synthetic hardware parameters, maximum physical
width, and a single total physical-shot allowance. Every target has coefficient
absolute sum at most one. Workload metadata records original normalization so
results can be converted back to application units.

Every executed target/Pauli/QPD/fragment experiment draws from the same allowance.
The runner uses independent data for each experiment and each target. Constants
consume no shots. Fixed equal or coefficient-based allocation is determined
before execution. A repeat is a new request with a new full allowance; repeated
results are never pooled into a single supposedly budget-limited answer.

Plans must fit physical width and connectivity after compilation. The shared
experiment cap is 2,048, with at most 256 joint QPD terms per Pauli term and
overhead at most 10,000. Automatic gate-cut search has at most 1,000 backjumps
and 20 seconds including process startup. The hard timer covers that search,
not all compilation or participant code. These limits are configurable Python
`Limits` fields; they are not universal circuit-cutting limits.

### Planner information and references

The participant hook receives a problem instance and candidate/resource data.
The organizer computes ideal statevector references separately from the
planner's call, against the actual supplied circuit. In particular, spin
references describe the supplied product-formula circuit, not exact continuous
Hamiltonian evolution. The latter would introduce a different approximation
error into the planner score.

The evaluator runs trusted Python code with access to local modules and files.
Keep reference values out of planner decisions. A final judging service must
separately control access to reference answers and execution resources.

### Accuracy and incomplete submissions

For each complete request/repetition, calculate the mean of the squared errors
across its targets. Average repetitions for that case, then cases within each
family/feasibility stratum. Give each required stratum equal weight and take the
square root. Thus the aggregate is a macro RMSE. This weights strata equally;
it is not automatically equal weighting of families with unequal stratum counts.

Every required case must have every declared repetition and every requested
target to receive a qualifying aggregate. A failed case is not dropped to
improve a method's score. Optional stress cases remain visible separately and
do not disqualify a method. Direct execution above the width limit is marked
unavailable. It therefore has no full-suite score when width-constrained cases
are required; compare it with other methods on matching direct-feasible strata.

The scorer rejects duplicate or out-of-design rows, missing targets on a claimed
success, nonfinite data, inconsistent reference values, invalid uncertainty
fields, failed reconstruction cross-checks, and width/budget violations.
Conditional completed-case errors are descriptive only when coverage differs.

The two repetitions in the workbook comparison demonstrate operation on the
supplied cases. Strong ranking or generalization claims need further evidence. Final
judging repetitions, weights, tie-breaks, and optional credit need approval.

### Uncertainty

Each target has an approximate plug-in standard error and a conservative
union-Hoeffding interval propagated through products and signed weights.
Bonferroni divides the total failure probability across requested targets for
simultaneous coverage. These guarantees require fixed allocation and the stated
stationary shot model. Intervals describe the reconstructed noisy estimands,
not unknown bias relative to the ideal circuit. Wide intervals are retained;
signed estimates are not clipped to the ideal observable's range.

Changing allocation adaptively or reusing measurements across targets requires
corresponding inference and covariance analysis. The coefficient allocator is a
heuristic; it does not claim optimal product-estimator variance.

### Generalization and controlled comparisons

The generator creates ten required cases per split with the
smoke preset: four families in two width regimes plus two controls. Public and
validation suites use four and six qubits respectively. A feasibility
calibration records all outcomes without filtering by favorable accuracy.
The optional standard generator preset has 20 cases per split: 18 required
cases and two optional expansion stresses. A private generator preset exists
for organizers with eight-qubit inputs and changed backend profiles, but no
private generated cases or seed records are distributed here. The notebooks
generate their own cases; command-line users generate suites explicitly.

Changes of size and backend are combined in those split presets. The separate
matched-condition generator isolates topology, noise strength, width, or shot
budget while preserving the exact circuits and targets. Its metadata identifies
the paired source, changed fields, and circuit/target hashes. Matching circuits
does not make simulator outputs a statistically paired measurement design;
the raw sampling seeds remain explicit.

Ideal basis-state controls have exact direct answers and zero sampling error.
A factorized no-cut plan can tie them. The toolkit does not label every
width-feasible circuit as one where direct execution is statistically optimal.

### Records and reproducibility

JSON retains case descriptions, environment, repetitions, uncertainty, plan
summaries, failure reasons, and organizer references. CSV has one row per target
per successful request; failed requests have a status row instead of fabricated
estimates. Both preserve planning and execution times, total shots, experiment
counts, width/depth, overhead, and shot-weighted two-qubit gates. Timing is a
diagnostic on the recorded machine, not a cross-platform competition score.

The plan export additionally records input instructions, selected gate cuts,
logical partitions, actual initial/final physical layouts, every shot allocation,
observable associations, and signed reconstruction products. It describes a
prepared plan; its separate execution result is the evidence that it ran.

Organizer-private manifests, individual results, references, and seed records
must stay outside the distributable directory. A final judge should generate
fresh cases if reserved cases become known or are used for tuning. Public
diagnostic reference values are deliberately included with the example results.
Keep generator versions, dependency pins, transpiler/search seeds, and
measurement seeds with results.


## Generator details

These generators support small, controlled
experiments with new circuits, graph structures, labels, sizes, and backend
conditions. They do not supply a proof of generalization or a final competition
distribution. The largest supported generated circuit has ten qubits.

### Start with one instance

```python
from wqcc_planner.instances import make_instance, HardwareProfile

instance = make_instance(
    "qaoa", generator_version=2, n_qubits=6, seed=2026,
    graph="modular", module_size=3, weighted=True, relabel=True,
    layers=1, max_width=3, shots=24000,
    hardware=HardwareProfile("example", "ring", 0.0008, 0.015, 0.006),
)
print(instance.instance_id)
print(instance.metadata["normalization"])
print(instance.metadata["logical_to_circuit"])
```

The returned object is the same one-observable `Instance` used by the planning
engine. Multi-observable packaging is handled by the toolkit's bundle layer.
`hardware` can also be a JSON-safe dictionary with the same fields. Supplying
`topology` overrides that profile's topology without changing its error rates.
Profiles are synthetic model parameters, not calibration data.

Calls with no version-2 options retain the original version-1 circuits and IDs.
Use `generator_version=2` explicitly in a reproducible experiment. Supplying a
new option such as `graph` also selects version 2 automatically. An explicit
version 1 combined with version-2 options is rejected to prevent silent changes.

### What varies

| Option | Meaning |
| --- | --- |
| `n_qubits` | Integer from 2 through 10. |
| `layers` | Integer from 1 through 4; each family defines a layer below. |
| `seed` | Nonnegative integer; independent RNG streams cover graph, angles, weights, and labels. |
| `graph` | `path`, `ring`, `star`, randomized `tree`, `matching`, or randomized `modular`. |
| `module_size` | Size of consecutive logical modules before relabeling; modular graphs have randomized internal trees and one bridge between consecutive modules. |
| `weighted` | Positive sampled edge weights in [0.5, 1.5] before global scaling; defaults to true in version 2. |
| `coupling_strength` | Positive global weight multiplier from 0.01 through 2. |
| `disorder` | Field-disorder amplitude from 0 through 0.9, used by spin and variational models. |
| `relabel` | True for a seeded permutation, false for original labels, or an explicit full permutation. Defaults to true in version 2. |
| `product_state` | Product controls: `random`, `zero`, `one`, or `alternating`. |

Changing a tree seed changes adjacency, not only rotation angles. Changing graph
kind also changes structural families. Relabeling maps logical index `q` to
`logical_to_circuit[q]`, permutes the observable consistently, and introduces no
physical SWAP gates. These circuit indices are still virtual qubits before
transpilation. A planner should not succeed only because useful modules happened
to be contiguous in the original labels.

Metadata contains logical and relabeled edges, actual weights, parameter values,
normalization, the label map, and a versioned fingerprint. Raw Hamiltonian terms
under `hamiltonian_logical` use original logical labels; apply the stored label
map before treating them as observables on the returned circuit. The primary
observable is already mapped correctly.

Version-2 instance IDs include a SHA-256-derived fingerprint of the actual gate
sequence, target observable, budget, width, hardware, and generator metadata.
Changing hardware parameters without changing the hardware name still changes
the ID. The fingerprint is for distinguishing specimens, not for authentication
or hiding a private seed. Exported metadata is JSON-safe and rejects nonfinite
coefficients or gate parameters. Width, shot, seed, and layer counts require
integers; floating counts and booleans are rejected.

### Family definitions

#### Weighted QAOA / MaxCut

For positive graph weights `w_e`, the classical cut Hamiltonian is

`C = sum_e w_e (I - Z_a Z_b) / 2`.

Starting from `|+>^n`, every layer applies `RZZ(-gamma * w_e)` on each edge,
then `RX(2*beta)` on every qubit. Up to a global phase this is the cost unitary
`exp(-i gamma C)` followed by `exp(-i beta sum X)`. Gate convention: [IBM RZZ documentation](https://quantum.cloud.ibm.com/docs/en/api/qiskit/qiskit.circuit.library.RZZGate).

The requested target is `sum_e w_e Z_a Z_b / sum_e w_e`. Thus `(1 - target)/2`
is the expected cut weight divided by total edge weight. This remains valid for
weighted graphs. It is not the probability of sampling the optimal cut. This
generator samples angles; it does not optimize QAOA parameters. Context:
[IBM QAOA tutorial](https://quantum.cloud.ibm.com/docs/en/tutorials/quantum-approximate-optimization-algorithm).

#### Disordered spin dynamics

The fixed, disordered Hamiltonian is

`H = sum_e J_e Z_a Z_b + sum_q h_q X_q + sum_q g_q Z_q`.

When disorder is nonzero, the ZZ couplings can have either sign, and transverse
and longitudinal fields vary by qubit. The initial state is `|+>^n`. One layer
is the first-order product formula

`U_step = exp(-i dt H_X) exp(-i dt H_Z)`.

The circuit applies all ZZ and Z rotations, then X rotations, with factors of
two set by Qiskit rotation definitions. `layers` steps use the same couplings
and fields; disorder does not fluctuate between time steps. The target is mean
transverse magnetization `sum X_q / n`. The supplied reference therefore scores
execution of this discretized circuit. It does not score Trotter approximation
error against exact evolution under the full Hamiltonian.

#### Variational energy estimation

Each layer contains parameterized local RY/RZ rotations and graph CNOTs. The
Hamiltonian uses the same disordered Ising form described above. The target
Hamiltonian is divided by the sum of absolute Pauli coefficients, giving an
operator-norm upper bound of one. Its energy can be converted back to original
units by multiplying by `metadata['normalization']['scale']`.

This is an energy-estimation workload at fixed sampled trial parameters. It is
not a full VQE optimization loop. Metadata includes the ansatz parameters and
the unnormalized Hamiltonian for reproducibility.

#### Controlled modular circuits

Version 2 prepares local rotations inside modules, applies internal CNOTs, and
uses seeded controlled RY or RZ rotations on intermodule edges. The control
direction, angle, and axis vary with the seed. Further local RX rotations make
the requested endpoint ZZ correlation sensitive to the circuit's interactions.
The stored control/target indices already reflect the qubit relabeling. Qiskit
control ordering is documented in the [CRY API](https://quantum.cloud.ibm.com/docs/en/api/qiskit/qiskit.circuit.library.CRYGate).

Edge weights scale the intermodule controlled-rotation angles. They do not turn
internal CNOTs into weighted Hamiltonian evolution. If a non-modular graph is
requested, module membership still determines which edges use CNOTs and which
use controlled rotations.

#### Analytic product controls

The primary target is mean Z. `zero` has ideal value +1; `one` has -1;
`alternating` has `1 - 2*k/n` where k is the number of one bits. A `random`
control applies independent RY rotations and has analytic mean `mean(cos(theta))`.
All qubits have explicit identity instructions so the cutting partitioner does
not discard idle wires that carry nonidentity observables.

With noiseless execution, basis-state controls have zero direct sampling error.
Cutting cannot improve that accuracy. A factorized plan without any gate cuts
can tie it; the control does not establish a uniquely optimal direct policy.
These simple, intentionally transparent checks help expose unnecessary work and
incorrect uncertainty or bit-order handling.

### Normalize and interpret the target

Every version-2 primary observable has coefficient L1 norm one after identical
Pauli terms are combined. `normalization.scale` records the original L1 norm;
`ideal_spectral_radius_upper_bound` is one. This makes absolute-error comparisons
more meaningful across sizes, although it does not make all tasks equally hard.
The bound concerns the ideal observable. It does not justify clipping a noisy
signed reconstruction or its uncertainty interval into [-1, 1].

### Create split specifications

```python
from wqcc_planner.suites import suite_specs
from wqcc_planner.instances import make_instance

records = suite_specs("public", master_seed=314, preset="smoke")
for record in records:
    instance = make_instance(**record["kwargs"])
    print(record["case_id"], record["stratum"], record["required"], instance.instance_id)
```

Each record has `kwargs`, `split`, `stratum`, `required`, and `case_id`. Only
`kwargs` are passed to `make_instance`. The other fields are suite bookkeeping.
The function writes no files. The caller controls where manifests, source
circuits, execution plans, and organizer reference values are stored.

| Split | Circuit size | Constrained width | Backend change |
| --- | ---: | ---: | --- |
| `public` | 4 | 2 | Lower synthetic errors; line/ring configurations. |
| `validation` | 6 | 3 | Changed error values and ring/all-to-all configurations. |
| `private` | 8 | 4 | Further changed error values and all-to-all/line configurations. |

The `smoke` preset has ten required cases: four families in direct-feasible and
width-constrained regimes, plus two product controls. `standard` has eighteen
required cases and two optional stresses. The second draw changes graph/angles
and can increase depth for circuits that fit; required width-constrained cases
keep one layer and two modules joined by one bridge. Optional ring/depth stresses
are permitted to exceed cutting caps and are not silently treated as mandatory
successful-execution cases.

The default allowance is 24,000 physical shots per base instance. A multi-target
wrapper must divide the shared allowance across targets; adding a second target
must not duplicate the allowance. All three split/preset namespaces derive
different seeds from `master_seed`. Their parameters are fully reproducible.

For a genuinely hidden evaluation, choose a fresh organizer-held master seed
and keep the generated private directory separate from the participant release.
A split label is not an access control, and the same published master seed is
not a secret. Notebook seeds and generated development examples are disclosed.

### Generated suites

No pre-generated dataset is needed for these notebooks. They construct their
own cases and save their manifests when run. Use the command-line examples
above to create a separate study. Recalibrate required cases when changing
width, depth, graph density, targets, budget, or planning limits. A reproducible
generator does not guarantee every generated instance fits the bounded runner.

### Matched-condition diagnostics

A split comparison can change circuit size, structure, seed, and backend at the
same time. Use the matched-condition helper to isolate a condition while keeping
the **exact same bound circuit and all named targets**. This is a diagnostic
experiment tool, not a new planner or a claim of causal validity on real hardware.

```text
python python/generate_matched_conditions.py --manifest data/my-public/manifest.json --axis topology --output data/paired-topology
python python/generate_matched_conditions.py --manifest data/my-public/manifest.json --axis noise --values 0,1,2 --output data/paired-noise
python python/generate_matched_conditions.py --manifest data/my-public/manifest.json --axis width --values 2,4 --output data/paired-width
python python/generate_matched_conditions.py --manifest data/my-public/manifest.json --axis shots --values 6000,12000,24000 --output data/paired-shots
```

Use your actual source-manifest path if its directory has a different name.
Default selection takes the first required, direct-feasible case in each of the
four challenge families, sorted by case ID. `--families qaoa,spin` selects a
subset; `--per-family 2` requires two eligible source cases from each selected
family. Controls and optional stress cases are not silently substituted.

| Axis | Default variants | Everything else held fixed |
| --- | --- | --- |
| `topology` | line, ring, all-to-all | Circuit, targets, width, noise rates, shot allowance. |
| `noise` | 0, 1, 2 times each source error rate | Circuit, targets, topology, width, shot allowance; error-rate ratios stay fixed. |
| `width` | half the circuit width, full width, full width + 2 (capped at 10) | Circuit, targets, topology family, noise parameters, shot allowance. |
| `shots` | half, same, double source allowance | Circuit, targets, hardware profile, width. |

`noise` is one **model-strength** axis: it scales one-qubit, two-qubit, and readout
rates together. It does not isolate which error channel mattered. To do that,
create a separately specified profile experiment. A completely ideal source
cannot gain noise by multiplication; such a requested sweep is rejected rather
than exporting identical specimens under misleading strength labels. Values
that exceed the hardware-profile parameter limits are rejected as well.

A width change changes how many physical vertices are available in the chosen
topology family. It can make direct execution unavailable or cause a cut plan to
exceed a cap. Record these outcomes alongside successful requests. The helper
uses the same resource limits for every variant.

Every exported variant gets a new fingerprinted ID and metadata:
`paired_source_case`, `paired_source_instance`, `paired_circuit_sha256`,
`paired_targets_sha256`, `changed_fields`, `matched_axis`, and `matched_value`.
The circuit digest hashes exact QPY bytes in the pinned environment. It is an
equality check within the exported experiment, not a version-independent
canonical quantum-circuit representation. Target order is preserved because it
can affect allocation tie-breaking and seeded execution.

The helper preserves one shared physical-shot allowance across targets.
Only a `shots` sweep changes that allowance; it never grants one full allowance
per target. The source circuit objects and metadata are not mutated. Source
manifest hashes are recorded, and existing nonempty output directories are
protected by the same suite-export checks as ordinary benchmarks.

Private source cases retain canonical `split="private"`. Their matched outputs
must remain outside the distributable toolkit directory. Calling a diagnostic
public does not remove this guard.

